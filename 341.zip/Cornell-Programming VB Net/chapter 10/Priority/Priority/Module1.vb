Option Strict On
Imports System.Threading
Module Module1
    Sub Main()
    Dim myTest As New WillUseThreads()
    Dim bThreadStart As New ThreadStart(AddressOf _
        myTest.SubtractFromCounter)
    Dim bThread As New Thread(bThreadStart)
    bThread.Priority = ThreadPriority.Highest
    bThread.Start()
    Dim i As Integer
    Do While True
      Console.WriteLine("In main thread and count is " & i)
      i += 1
    Loop
    End Sub
  End Module


Public Class WillUseThreads
  Public Sub SubtractFromCounter()
    Dim count As Integer
    Do While True
      count -= 1
      Console.WriteLine("Am in another thread and counter  =" _
      & count)
    Loop
  End Sub
End Class
