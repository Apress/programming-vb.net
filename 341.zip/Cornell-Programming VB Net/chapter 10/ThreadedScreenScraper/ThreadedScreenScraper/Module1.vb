Option Strict On
Imports System.IO
Imports System.Net
Imports System.ThreadIng
Module Module1

  Sub Main()
    Console.WriteLine("I will display the current rankings of " _
    & "four books on Amazon.")
    Console.WriteLine()
    Dim theBook(3, 1) As String
    theBook(0, 0) = "1893115992"
    theBook(0, 1) = "Programming VB .NET"
    theBook(1, 0) = "1893115291"
    theBook(1, 1) = "Database Programming VB .NET"
    theBook(2, 0) = "1893115623"
    theBook(2, 1) = "Programmer�s Introduction to C#, "
    theBook(3, 0) = "1893115593"
    theBook(3, 1) = "C# and the .Net Platform "
    Dim i As Integer
    Dim theRanker As AmazonRanker
    Dim aThreadStart As Threading.ThreadStart
    Dim aThread As Threading.Thread
    For i = 0 To 3
      Try
        theRanker = New AmazonRanker(theBook(i, 0), theBook(i, 1))
        aThreadStart = New ThreadStart(AddressOf theRanker.FindRank)
        aThread = New Thread(aThreadStart)
        aThread.Name = theBook(i, 1)
        aThread.Start()
      Catch e As Exception
        Console.WriteLine(e.Message)
      End Try
    Next
    Console.ReadLine()
  End Sub

End Module

Public Class AmazonRanker
  Private m_URL As String
  Private m_Rank As Integer
  Private m_Name As String
  Public Sub New(ByVal ISBN As String, ByVal theName As String)
    m_URL = "http://www.amazon.com/exec/obidos/ASIN/" & ISBN
    m_Name = theName
  End Sub

  Public Sub FindRank()
    m_Rank = ScrapeAmazon()
    Console.WriteLine("The rank of " & m_Name & " is " _
    & GetRank)
  End Sub

  Public ReadOnly Property GetRank() As String
    Get
      If m_Rank <> 0 Then
        Return CStr(m_Rank)
      Else
        'problems
      End If
    End Get
  End Property

  Public ReadOnly Property GetName() As String
    Get
      Return m_Name
    End Get
  End Property
  Private Function ScrapeAmazon() As Integer
    Try
      Dim theURL As New Uri(m_URL)
      Dim theRequest As WebRequest
      theRequest = WebRequest.Create(theURL)
      Dim theResponse As WebResponse
      theResponse = theRequest.GetResponse
      Dim aReader As New StreamReader(theResponse.GetResponseStream())
      Dim theData As String
      theData = aReader.ReadToEnd
      Return Analyze(theData)
    Catch E As Exception
      Console.WriteLine(E.Message)
      Console.WriteLine(E.StackTrace)
      Console.ReadLine()
    End Try
  End Function

  Private Function Analyze(ByVal theData As String) As Integer
    Dim Location As Integer
    Location = theData.IndexOf("<b>Amazon.com Sales Rank: </b>") _
    + "<b>Amazon.com Sales Rank: </b>".Length
    Dim temp As String
    Do Until theData.Substring(Location, 1) = "<"
      temp = temp & theData.Substring(Location, 1)
      Location += 1
    Loop
    Return CInt(temp)
  End Function
End Class
