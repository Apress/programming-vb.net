Option Strict On
Imports System.Threading
Module Module1
  Sub Main()
    Dim myTest As New WillUseThreads()
    Dim aThreadStart As New Threading.ThreadStart(AddressOf myTest.AddToCounter)
    Dim aThread As New Thread(aThreadStart)
    aThread.Name = "increasing thread"
    Dim bThreadStart As New Threading.ThreadStart(AddressOf myTest.SubtractFromCounter)
    Dim bThread As New Thread(AddressOf myTest.SubtractFromCounter)
    bThread.Name = "decreasing thread"
    aThread.Start()
    bThread.Start()
  End Sub
End Module

Public Class WillUseThreads
  Public Sub AddToCounter()
    Dim count As Integer
    Do While True
      count += 1
      Console.WriteLine("Am in thread named " & Thread.CurrentThread.Name & " counter  =" & count)
      If count Mod 100 = 0 Then
        Try
          Thread.Sleep(1000)
        Catch e As ThreadInterruptedException
          'thread interrupted from sleeping   
        End Try
      End If
    Loop
  End Sub
  Public Sub SubtractFromCounter()
    Dim count As Integer
    Do
      count -= 1
      Console.WriteLine("Am in thread named " & Thread.CurrentThread.Name & " counter  =" & count)
      If count Mod 200 = 0 Then
        Try
          Thread.Sleep(1000)
        Catch e As ThreadInterruptedException
          'thread interrupted from sleeping   
        End Try
      End If
    Loop
  End Sub
End Class