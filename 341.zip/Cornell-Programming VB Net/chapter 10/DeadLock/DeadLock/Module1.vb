Option Strict On
Imports System.Threading
Module Module1
  Sub Main()
    Dim Tom As New Programmer("Tom")
    Dim Bob As New Programmer("Bob")
    Dim aThreadStart As New ThreadStart(AddressOf Tom.Eat)
    Dim aThread As New Thread(aThreadStart)
    aThread.Name = "Tom"
    Dim bThreadStart As New ThreadStart(AddressOf Bob.Eat)
    Dim bThread As New Thread(bThreadStart)
    bThread.Name = "Bob"
    aThread.Start()
    bThread.Start()
  End Sub
End Module

Public Class Fork
  Private Shared mForkAvailable As Boolean = True
  Private Shared mOwner As String = "Nobody"
  Private ReadOnly Property OwnsUtensil() As String
    Get
      Return mOwner
    End Get
  End Property
  Public Sub GrabFork(ByVal a As Programmer)
    Console.WriteLine(Thread.CurrentThread.Name & " trying to grab the fork.")
    Console.WriteLine(Me.OwnsUtensil & " has the fork.")
    Monitor.Enter(Me) 'SyncLock (aFork) '
    If mForkAvailable Then
      a.HasFork = True
      mOwner = a.MyName
      mForkAvailable = False
      Console.WriteLine(a.MyName & " just got the fork, waiting")
      Thread.Sleep(100)
    End If
    Monitor.Exit(Me) 'End SyncLock
  End Sub
End Class

Public Class Knife
  Private Shared mKnifeAvailable As Boolean = True
  Private Shared mOwner As String = "Nobody"
  Private ReadOnly Property OwnsUtensil() As String
    Get
      Return mOwner
    End Get
  End Property
  Public Sub GrabKnife(ByVal a As Programmer)
    Console.WriteLine(Thread.CurrentThread.Name & " trying to grab the knife.")
    Console.WriteLine(Me.OwnsUtensil & " has the knife.")
    Monitor.Enter(Me) 'SyncLock (aKnife) '
    If mKnifeAvailable Then
      mKnifeAvailable = False
      a.HasKnife = True
      mOwner = a.MyName
      Console.WriteLine(a.MyName & " just got the knife, waiting")
      Thread.Sleep(100)
    End If
    Monitor.Exit(Me)
  End Sub
End Class
Public Class Programmer
  Private mName As String
  Private Shared mFork As Fork
  Private Shared mKnife As Knife
  Private mHasKnife As Boolean
  Private mHasFork As Boolean
  Shared Sub New()
    mFork = New Fork()
    mKnife = New Knife()
  End Sub
  Public Sub New(ByVal theName As String)
    mName = theName
  End Sub
  Public ReadOnly Property MyName() As String
    Get
      Return mName
    End Get
  End Property
  Public Property HasKnife() As Boolean
    Get
      Return mHasKnife
    End Get
    Set(ByVal Value As Boolean)
      mHasKnife = Value
    End Set
  End Property
  Public Property HasFork() As Boolean
    Get
      Return mHasFork
    End Get
    Set(ByVal Value As Boolean)
      mHasFork = Value
    End Set
  End Property

  Public Sub Eat()
    Do Until Me.HasKnife And Me.HasFork
      Console.WriteLine(Thread.CurrentThread.Name & " is in the thread.")
      If Rnd() < 0.5 Then
        mFork.GrabFork(Me)
      Else
        mKnife.GrabKnife(Me)
      End If
    Loop
    MsgBox(Me.MyName & " can eat!")
    mKnife = New Knife()
    mFork = New Fork()
  End Sub
End Class
