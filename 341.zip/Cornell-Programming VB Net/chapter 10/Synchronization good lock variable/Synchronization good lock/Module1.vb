Option Strict On
Imports System.Threading
Module Module1

  Sub Main()
    Dim myHouse As New House(10)
    Console.ReadLine()
  End Sub

End Module


Public Class House
  Public Const MAX_TEMP As Integer = 75
  Private mCurTemp As Integer = 55
  Private mRooms() As Room
  Public Sub New(ByVal numOfRooms As Integer)
    ReDim mRooms(numOfRooms - 1)
    Dim i As Integer
    Dim aThreadStart As Threading.ThreadStart
    Dim aThread As Thread
    For i = 0 To numOfRooms - 1
      mRooms(i) = New Room(Me, mCurTemp, CStr(i) & "'th room")
      aThreadStart = New ThreadStart(AddressOf mRooms(i).CheckTempInRoom)
      aThread = New Thread(aThreadStart)
      aThread.Name = CStr(i) & "'th room"
      aThread.Start()
    Next
  End Sub
  Public Property HouseTemp() As Integer
    Get
      Return mCurTemp
    End Get
    Set(ByVal Value As Integer)
      mCurTemp = Value
    End Set
  End Property
End Class

Public Class Room
  Private mCurTemp As Integer
  Private mName As String
  Private mHouse As House

  Public Sub New(ByVal theHouse As House, ByVal temp As Integer, ByVal roomName As String)
    mHouse = theHouse
    mCurTemp = temp
    mName = roomName
  End Sub

  Public Sub CheckTempInRoom()
    Try
      ChangeTemperature()
    Catch E As ThreadInterruptedException
      'thread ended 
    End Try
  End Sub

  Private Sub ChangeTemperature()
    SyncLock (mHouse)
      If mHouse.HouseTemp < mHouse.MAX_TEMP - 5 Then
        Thread.CurrentThread.Sleep(200)
        mHouse.HouseTemp += 5
        Console.WriteLine("Am in " & Me.mName & _
      " Current temperature is " & mHouse.HouseTemp)
      ElseIf mHouse.HouseTemp < mHouse.MAX_TEMP Then
        Thread.CurrentThread.Sleep(200)
        mHouse.HouseTemp += 1
        Console.WriteLine("Am in " & Me.mName & _
      " Current temperature is " & mHouse.HouseTemp)
      Else
        Console.WriteLine("Am in " & Me.mName & _
     " Current temperature is " & mHouse.HouseTemp)
        'Do nothing temp OK
      End If
    End SyncLock
  End Sub
End Class