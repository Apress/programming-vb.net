Option Strict On
Imports System.Text
Imports System.Threading
Public Class Form1
  Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

  Public Sub New()
    MyBase.New()

    'This call is required by the Windows Form Designer.
    InitializeComponent()

    'Add any initialization after the InitializeComponent() call

  End Sub

  'Form overrides dispose to clean up the component list.
  Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
    If disposing Then
      If Not (components Is Nothing) Then
        components.Dispose()
      End If
    End If
    MyBase.Dispose(disposing)
  End Sub
  Friend WithEvents btnSTart As System.Windows.Forms.Button
  Friend WithEvents btnCancel As System.Windows.Forms.Button
  Friend WithEvents btnShowCount As System.Windows.Forms.Button

  'Required by the Windows Form Designer
  Private components As System.ComponentModel.Container

  'NOTE: The following procedure is required by the Windows Form Designer
  'It can be modified using the Windows Form Designer.  
  'Do not modify it using the code editor.
  <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.btnShowCount = New System.Windows.Forms.Button()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.btnSTart = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btnShowCount
        '
        Me.btnShowCount.Enabled = False
        Me.btnShowCount.Location = New System.Drawing.Point(154, 276)
        Me.btnShowCount.Name = "btnShowCount"
        Me.btnShowCount.Size = New System.Drawing.Size(92, 30)
        Me.btnShowCount.TabIndex = 2
        Me.btnShowCount.Text = "Show count"
        '
        'btnCancel
        '
        Me.btnCancel.Location = New System.Drawing.Point(292, 276)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(72, 30)
        Me.btnCancel.TabIndex = 1
        Me.btnCancel.Text = "Cancel"
        '
        'btnSTart
        '
        Me.btnSTart.Location = New System.Drawing.Point(36, 276)
        Me.btnSTart.Name = "btnSTart"
        Me.btnSTart.Size = New System.Drawing.Size(72, 30)
        Me.btnSTart.TabIndex = 0
        Me.btnSTart.Text = "Start"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(6, 15)
        Me.ClientSize = New System.Drawing.Size(399, 323)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnShowCount, Me.btnCancel, Me.btnSTart})
        Me.Name = "Form1"
        Me.Text = "Win Forms With Invoke"
        Me.ResumeLayout(False)

    End Sub

#End Region
  Private m_RC As RandomCharacters
  Private Sub btnSTart_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSTart.Click
    m_RC = New RandomCharacters(10000000, Me.btnShowCount)
    Dim myThreadStart As New ThreadStart(AddressOf m_RC.StartCount)
        Dim myThread As New Thread(myThreadStart)
        Thread.CurrentThread.Priority = ThreadPriority.Highest
        myThread.Priority = ThreadPriority.Lowest
    Try
      myThread.Start()
    Catch threadException As ThreadInterruptedException
      MsgBox("Thread exception")
    End Try
  End Sub
    Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        System.Environment.Exit(0)
        'MsgBox("Count Interrupted!")
    End Sub
    Private Sub btnShowCount_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnShowCount.Click
        If m_RC.IsDone Then
            MsgBox(m_RC.GetCount)
        Else
            MsgBox("Count not done!")
        End If
        btnShowCount.Enabled = False
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class
Public Class RandomCharacters
    Private m_Data As StringBuilder
    Private m_CountDone As Boolean
    Private m_length, m_count As Integer
    Private m_Button As Windows.Forms.Button
    Public Sub New(ByVal n As Integer, ByVal b As Windows.Forms.Button)
        m_length = n - 1
        m_Data = New StringBuilder(m_length)
        m_Button = b
        MakeString()
    End Sub
    Private Sub MakeString()
        Dim I As Integer
        Dim myRnd As New Random()
        For I = 0 To m_length
            m_Data.Append(Chr(myRnd.Next(65, 90)))
        Next
    End Sub
    Public Sub StartCount()
        GetEes()
    End Sub
    Private Sub GetEes()
        Dim I As Integer
        For I = 0 To m_length
            If m_Data.Chars(I) = CChar("E") Then
                m_count += 1
            End If
            ' this line will show that teh cancel button works
            If I = 500000 Then MsgBox("at i =500000")
        Next
        m_CountDone = True
        Try
            Dim myInvoker As New MethodInvoker(AddressOf UpDateButton)
            myInvoker.Invoke()
        Catch e As ThreadInterruptedException
            'oops
        End Try
    End Sub
    Public Sub UpDateButton()
        m_Button.Enabled = True
    End Sub
    Public ReadOnly Property GetCount() As Integer
        Get
            If Not (m_CountDone) Then
                Throw New Exception("Count not yet done")
            Else
                Return m_count
            End If
        End Get
    End Property
    Public ReadOnly Property IsDone() As Boolean
        Get
            Return m_CountDone
        End Get
    End Property
End Class