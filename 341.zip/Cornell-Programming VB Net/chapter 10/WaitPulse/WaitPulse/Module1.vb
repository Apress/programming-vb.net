Option Strict On
Imports System.Threading
Module Module1
  Sub Main()
    Dim theFamily As New Family()
    theFamily.StartItsLife()
  End Sub
End Module

Public Class Family
  Private mMoney As Integer
  Private mWeek As Integer = 1
  Public Sub StartItsLife()
    Dim aThreadStart As New ThreadStart(AddressOf Me.Produce)
    Dim bThreadStart As New ThreadStart(AddressOf Me.Consume)
    Dim aThread As New Thread(aThreadStart)
    Dim bThread As New Thread(bThreadStart)
    aThread.Name = "Produce"
    aThread.Start()
    bThread.Name = "Consume"
    bThread.Start()
  End Sub
  Public Property TheWeek() As Integer
    Get
      Return mWeek
    End Get
    Set(ByVal Value As Integer)
      mWeek = Value
    End Set
  End Property
  Public Property OurMoney() As Integer
    Get
      Return mMoney
    End Get
    Set(ByVal Value As Integer)
      mMoney = Value
    End Set
  End Property
  Public Sub Produce()
    Thread.Sleep(500)
    Do
      Monitor.Enter(Me)
      Do While Me.OurMoney > 0
        Monitor.Wait(Me)
      Loop
      Me.OurMoney = 1000
      Monitor.PulseAll(Me)
      Monitor.Exit(Me)
    Loop
  End Sub
  Public Sub Consume()
    MsgBox("AM in consume thread")
    Do
      Monitor.Enter(Me)
      Do While Me.OurMoney = 0
        Monitor.Wait(Me)
      Loop
      Console.WriteLine("Dear parent I just spent all your money in week " & TheWeek)
      TheWeek += 1
      If TheWeek = 21 * 52 Then System.Environment.Exit(0)
      Me.OurMoney = 0
      Monitor.PulseAll(Me)
      Monitor.Exit(Me)
    Loop
  End Sub
End Class

