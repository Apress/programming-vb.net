Option Strict On
Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu
    Friend WithEvents mnuExit As System.Windows.Forms.MenuItem
    Friend WithEvents mnuFile As System.Windows.Forms.MenuItem
    Friend WithEvents mnuNew As System.Windows.Forms.MenuItem

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.MainMenu1 = New System.Windows.Forms.MainMenu()
        Me.mnuFile = New System.Windows.Forms.MenuItem()
        Me.mnuNew = New System.Windows.Forms.MenuItem()
        Me.mnuExit = New System.Windows.Forms.MenuItem()
        '
        'MainMenu1
        '
        Me.MainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuFile})
        '
        'mnuFile
        '
        Me.mnuFile.Index = 0
        Me.mnuFile.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuNew, Me.mnuExit})
        Me.mnuFile.Text = "File"
        '
        'mnuNew
        '
        Me.mnuNew.Index = 0
        Me.mnuNew.Text = "New"
        '
        'mnuExit
        '
        Me.mnuExit.Index = 1
        Me.mnuExit.Text = "Exit"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(6, 15)
        Me.ClientSize = New System.Drawing.Size(292, 272)
        Me.Menu = Me.MainMenu1
        Me.Name = "Form1"
        Me.Text = "MDI Example 2"

    End Sub

#End Region

    Private Sub Form1_Load(ByVal sender As System.Object, _
  ByVal e As System.EventArgs) _
  Handles MyBase.Load
        Me.Text = "I'm an MDI Parent"
        Me.IsMdiContainer = True
        Dim MyChild As New System.Windows.Forms.Form()
        MyChild.MdiParent = Me
        MyChild.Show()
        MyChild.Text = "First MDI Child"
        InitializeMenu()
    End Sub
    Public Sub InitializeMenu()
        Dim mnuWindow As New MenuItem("&Window")
        MainMenu1.MenuItems.Add(mnuWindow)
        mnuWindow.MenuItems.Add(New MenuItem _
        ("&Cascade", AddressOf WindowCascade_Clicked))
        mnuWindow.MenuItems.Add(New MenuItem _
        ("Tile &Horizontal", AddressOf WindowTileHoriz_Clicked))
        mnuWindow.MenuItems.Add(New MenuItem _
        ("Tile &Vertical", AddressOf WindowTileVert_Clicked))
        mnuWindow.MdiList = True
    End Sub

    Protected Sub WindowCascade_Clicked(ByVal Sender As Object, _
      ByVal e As System.EventArgs)
        Me.LayoutMdi(MdiLayout.Cascade)
    End Sub

    Protected Sub WindowTileHoriz_Clicked(ByVal Sender As Object, _
      ByVal e As System.EventArgs)
        Me.LayoutMdi(MdiLayout.TileHorizontal)
    End Sub

    Protected Sub WindowTileVert_Clicked(ByVal Sender As Object, _
      ByVal e As System.EventArgs)
        Me.LayoutMdi(MdiLayout.TileVertical)
    End Sub

    Private Sub mnuExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuExit.Click
        System.Environment.Exit(0)
    End Sub

    
    Private Sub mnuNew_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuNew.Click
        Static numOfChildren As Integer = 2
        Dim MyChild As New System.Windows.Forms.Form()
        MyChild.MdiParent = Me
        MyChild.Show()
        MyChild.Text = "MDI Child " & CStr(numOfChildren)
        numOfChildren += 1
    End Sub
End Class
