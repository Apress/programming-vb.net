Option Strict On
Module Module1
    Public Sub Main()
        Dim myForm As New Form1()
        If myForm.ShowDialog() = DialogResult.Cancel Then
            MsgBox("You pressed the cancel button")
        Else
            MsgBox("You pressed OK.")
        End If
    End Sub
End Module
