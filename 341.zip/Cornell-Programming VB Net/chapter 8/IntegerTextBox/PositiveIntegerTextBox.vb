Option Strict On
Imports System.ComponentModel
<DefaultEvent("BadDataEntered")> Public Class PositiveIntegerTextBox
    Inherits System.Windows.Forms.TextBox
    Public Event BadDataEntered(ByVal Sender As Object, _
    ByVal e As EventArgs)
    Protected Overrides Sub OnTextChanged(ByVal e As EventArgs)
        MyBase.OnTextChanged(e)
        If Not (IsNumeric(Me.Text)) Then
            Me.Text = String.Empty
            RaiseEvent BadDataEntered(Me, New System.EventArgs())
        Else
            Dim temp As Decimal
            temp = CType(Me.Text, Decimal)
            If temp - Math.Round(temp, 0) <> 0 Then
                Me.Text = String.Empty
                RaiseEvent BadDataEntered(Me, New System.EventArgs())
            End If
        End If
    End Sub
    Private m_Min As Long = 1
    Private m_Max As Long = Long.MaxValue
    <Browsable(True)> Public Property MinValue() As Long
        Get
            Return m_Min
        End Get
        Set(ByVal Value As Long)
            m_Min = Math.Max(1, Value)
        End Set
    End Property
    <Browsable(True)> Public Property MaxValue() As Long
        Get
            Return m_Max
        End Get
        Set(ByVal Value As Long)
            m_Max = Math.Min(m_Min, Value)
        End Set
    End Property
    <Browsable(False)> Public Overrides Property Text() As String
        Get
            Return MyBase.Text
        End Get
        Set(ByVal Value As String)
            MyBase.Text = Value
        End Set
    End Property


End Class

