Option Strict On
Imports System.Drawing
Public Class Form1
  Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

  Public Sub New()
    MyBase.New()

    'This call is required by the Windows Form Designer.
    InitializeComponent()

    'Add any initialization after the InitializeComponent() call

  End Sub

  'Form overrides dispose to clean up the component list.
  Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
    If disposing Then
      If Not (components Is Nothing) Then
        components.Dispose()
      End If
    End If
    MyBase.Dispose(disposing)
  End Sub
  Friend WithEvents PictureBox1 As FontPictureBox
  Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip
    Friend WithEvents ToolTip2 As System.Windows.Forms.ToolTip
  Private components As System.ComponentModel.IContainer
      
  'Required by the Windows Form Designer
  
  'NOTE: The following procedure is required by the Windows Form Designer
  'It can be modified using the Windows Form Designer.  
  'Do not modify it using the code editor.
  <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
    Me.components = New System.ComponentModel.Container()
    Me.ToolTip2 = New System.Windows.Forms.ToolTip(Me.components)
    Me.PictureBox1 = New AllFonts.FontPictureBox()
    Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
    Me.SuspendLayout()
    '
    'PictureBox1
    '
    Me.PictureBox1.BackColor = System.Drawing.Color.FromArgb(CType(255, Byte), CType(255, Byte), CType(192, Byte))
    Me.PictureBox1.Location = New System.Drawing.Point(56, 16)
    Me.PictureBox1.Name = "PictureBox1"
    Me.PictureBox1.Size = New System.Drawing.Size(835, 31285)
    Me.PictureBox1.TabIndex = 0
    Me.PictureBox1.TabStop = False
    '
    'Form1
    '
    Me.AutoScaleBaseSize = New System.Drawing.Size(6, 15)
    Me.ClientSize = New System.Drawing.Size(336, 352)
    Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.PictureBox1})
    Me.Name = "Form1"
    Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
    Me.Text = "All your fonts!"
    Me.ResumeLayout(False)

  End Sub
#End Region
  Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
    Me.VScroll = True
    Me.HScroll = True
    Me.AutoScroll = True
    PictureBox1.Left = 0
    PictureBox1.Top = 0
  End Sub

  Protected Overrides Sub OnPaint(ByVal e As System.Windows.Forms.PaintEventArgs)
    MyBase.OnPaint(e)
  End Sub
End Class

Public Class FontPictureBox
  Inherits System.Windows.Forms.PictureBox
  Protected Overrides Sub OnPaint(ByVal pe As System.Windows.Forms.PaintEventArgs)
    MyBase.OnPaint(pe)
    DisplayFonts(pe.Graphics)

  End Sub
  Private Sub DisplayFonts(ByVal g As Graphics)
    'Dim g As Graphics = Me.CreateGraphics()
    Dim aFontFamily As FontFamily
    Dim curx, curY As Single
    Dim TheFonts As System.Drawing.Text.FontCollection
    Dim tempFont As Font
    Dim spacing As Integer = 2 '2 pixels apart
    TheFonts = New System.Drawing.Text.InstalledFontCollection()
    For Each aFontFamily In TheFonts.Families
      Me.Height += 2
      If aFontFamily.IsStyleAvailable(FontStyle.Regular) Then
        tempFont = New Font(aFontFamily, 14, FontStyle.Regular)
      ElseIf aFontFamily.IsStyleAvailable(FontStyle.Bold) Then
        tempFont = New Font(aFontFamily, 14, FontStyle.Bold)
      ElseIf aFontFamily.IsStyleAvailable(FontStyle.Italic) Then
        tempFont = New Font(aFontFamily, 14, FontStyle.Italic)
      End If
      g.DrawString("This is displayed in " & aFontFamily.Name, _
       tempFont, Brushes.Black, curx, curY)
      Dim theSize As SizeF = g.MeasureString("This text is displayed in " _
      & aFontFamily.Name, tempFont)
      curY = curY + theSize.Height + spacing
      Me.Height = Me.Height + CInt(theSize.Height) + spacing
      Me.Width = Math.Max(CInt(theSize.Width), Me.Width)
    Next
  End Sub
End Class


