Option Strict On
Module Module1
  Sub Main()
    Dim myList As New ArrayList()
    Dim theData As String
    Console.Write("Please enter each item and hit Enter key," _
      & " enter ZZZ when done: ")
    theData = Console.ReadLine()
    Do Until theData = "ZZZ"
      myList.Add(theData)
      Console.Write("Please enter each item and hit Enter, " _
       & " enter ZZZ when done: ")
      theData = Console.ReadLine()
    Loop
    Console.WriteLine("You entered " & myList.Count() & " ITEMS.")
    Console.ReadLine()
  End Sub
End Module
