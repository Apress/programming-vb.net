Option Strict On
Imports System.Environment
Module Module1
    Sub Main()
      Dim eVariables As Hashtable
      eVariables = CType(GetEnvironmentVariables(), Hashtable)
      Console.WriteLine("Press Enter to see the next item")
      Dim thing As Object
      For Each thing In eVariables.Keys
            Console.WriteLine("The environment variable named " & thing.ToString() _
            & " has value " & eVariables(thing).ToString())
        Console.ReadLine()
      Next
    End Sub
  End Module
