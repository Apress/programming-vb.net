Option Strict On
Module Module1
  Sub Main()
    Dim fooaLinkedList As New LinkedList("first link")
    Dim aLink As LinkedList.Link
    aLink = fooaLinkedList.MakeLink(fooaLinkedList.GetFirstLink, _
"second link")
    aLink = fooaLinkedList.MakeLink(aLink, "third link")
    Console.WriteLine(fooaLinkedList.GetFirstLink.MyData)
    aLink = fooaLinkedList.GetNextLink(fooaLinkedList.GetFirstLink)
    Console.WriteLine(aLink.MyData)
    Console.WriteLine(aLink.NextLink.MyData)
    Console.ReadLine()
  End Sub
  Public Class LinkedList
    Private m_CurrentLink As Link
    Private m_FirstLink As Link
    Sub New(ByVal theData As String)
      m_CurrentLink = New Link(theData)
      m_FirstLink = m_CurrentLink
    End Sub
    Public Function MakeLink(ByVal currentLink As Link, ByVal _
theData As String) As Link
      m_CurrentLink = New Link(currentLink, theData)
      Return m_CurrentLink
    End Function
    Public ReadOnly Property GetNextLink(ByVal aLink As Link) _
As Link
      Get
        Return aLink.NextLink()
      End Get
    End Property
    Public ReadOnly Property GetCurrentLink() As Link
      Get
        Return m_CurrentLink
      End Get
    End Property
    Public ReadOnly Property GetFirstLink() As Link
      Get
        Return m_FirstLink
      End Get
    End Property


    'nested class for link objects
    Friend Class Link
      Private m_MyData As String
      Private m_NextLink As Link
      Friend Sub New(ByVal myParent As Link, ByVal theData As String)
        m_MyData = theData
        myParent.m_NextLink = Me
      End Sub
      Friend Sub New(ByVal theData As String)
        m_MyData = theData
      End Sub
      Friend ReadOnly Property MyData() As String
        Get
          Return m_MyData
        End Get
      End Property
      Friend ReadOnly Property NextLink() As Link
        Get
          Return m_NextLink
        End Get
      End Property
    End Class
  End Class
End Module
