Option Strict On
Module Module1
  Sub Main()
        Dim Tom As New Employee("Tom", 100000)
        System.Console.WriteLine(Tom.TheName & " is employee# " & _
    Tom.EmployeeId & "  with salary " & Tom.Salary())
        Dim Sally As New Employee("Sally", 150000)
        System.Console.WriteLine(Sally.TheName & " is employee# " & _
        Sally.EmployeeId & " with salary " & Sally.Salary())
        System.Console.WriteLine("Please press the Enter key")
        System.Console.Read()
    End Sub
End Module

Public Class Employee
    Private m_Name As String
    Private m_Salary As Decimal
    Private Shared m_EmployeeID As Integer = 10000
    Private m_MyID As Integer
  Public Sub New(ByVal thesName As String, ByVal curSalary As Decimal)
        m_Name = thesName
        m_Salary = curSalary
        m_EmployeeID = m_EmployeeID + 1
        m_MyID = m_EmployeeID
  End Sub
  ReadOnly Property EmployeeId() As Integer
    Get
            Return m_MyID
    End Get
  End Property
  ReadOnly Property TheName() As String
    Get
      TheName = m_Name
    End Get
  End Property
  ReadOnly Property Salary() As Decimal
    Get
      Salary = m_Salary
    End Get
  End Property
End Class

