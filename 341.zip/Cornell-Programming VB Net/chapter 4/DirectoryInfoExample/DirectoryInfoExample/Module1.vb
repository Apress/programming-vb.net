Option Strict On
Imports System.IO
Module Module1
  Sub Main()
    Dim dirInfo As New DirectoryInfo("C:\")
    ListDirectories(dirInfo)
  End Sub

  Sub ListDirectories(ByVal theDirectory As DirectoryInfo)
    Dim tempDir As DirectoryInfo
    Console.WriteLine(theDirectory.FullName())
    For Each tempDir In theDirectory.GetDirectories()
      ListDirectories(tempDir)
    Next
  End Sub
End Module