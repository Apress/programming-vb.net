Option Strict On
Module Module1
  Sub Main()
    Dim a As String = "hello"
    NoProblem(a)
    Console.WriteLine("After passing by value the string is still " & a)
    Console.ReadLine()
  End Sub

  Sub NoProblem(ByVal foo As String)
    foo = "goodbye"
  End Sub
End Module
