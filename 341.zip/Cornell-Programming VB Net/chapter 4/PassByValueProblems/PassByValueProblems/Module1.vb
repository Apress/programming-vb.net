Option Strict On
Module Module1
  Sub Main()
    Dim A() As String = {"HELLO", "GOODBYE"}
    Console.WriteLine("Original first item in array is: " _
      & A(0))
    Console.WriteLine("Original second item in array is: " _
      & A(1))
    Yikes(A)
    Console.WriteLine("After passing by value first item in array now is: " _
      & A(0))
    Console.WriteLine("After passing by value second item in array is: " _
      & A(1))
    Console.ReadLine()
  End Sub

  Sub Yikes(ByVal Foo As String())
    Foo(0) = "GOODBYE"
    Foo(1) = "HELLO"
  End Sub
End Module

