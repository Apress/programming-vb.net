Option Strict On
Module Test1
  Sub Main()
        Dim Tom As New Employee("tom", 10000)
        Console.WriteLine(Tom.TheName & " salary is " & Tom.Salary)
        Console.WriteLine(Tom)
        Console.ReadLine()
  End Sub
    'define the class
  Public Class Employee
    Private m_Name As String
    Private m_Salary As Decimal
    Public Sub New(ByVal sName As String, ByVal curSalary As Decimal)
            If sName = String.Empty Then
                MsgBox("Hey employees with no names don't make much sense")
            Else
                m_Name = sName
            End If
            If curSalary > 100000 Then
                MsgBox("who are you kidding")
            Else
                m_Salary = curSalary
            End If
    End Sub
        Public Property TheName() As String
            Get
                Return m_Name
            End Get
            Set(ByVal Value As String)
                m_Name = Value
            End Set
        End Property
        Public ReadOnly Property Salary() As Decimal
            Get
                Return m_Salary
            End Get
        End Property
        Public Overrides Function ToString() As String
            Return (m_Name & " " & Me.GetType.ToString)
        End Function

    End Class
End Module
