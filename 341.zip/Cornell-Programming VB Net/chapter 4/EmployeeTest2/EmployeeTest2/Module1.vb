Option Strict On
Module Module1
  Sub Main()
        Dim Tom As New Employee("Tom", 100000)
        Console.WriteLine(Tom.TheName & "  has salary " & Tom.Salary)
        Tom.RaiseSalary(0.2D) 'D necessary for decimal
        Console.WriteLine(Tom.TheName & " still has salary " & Tom.Salary)
        Console.WriteLine()
        Dim Sally As New Employee("Sally", 150000)
        Console.WriteLine(Sally.TheName & " has salary " & Sally.Salary)
        Sally.RaiseSalary(0.2D, "special") 'D necessary for decimal
        Console.WriteLine(Sally.TheName & " has salary " & Sally.Salary)
        Console.WriteLine()
        Console.WriteLine("Please press the Enter key")
        Console.ReadLine()
  End Sub
End Module
Public Class Employee
    Private m_Name As String
    Private m_Salary As Decimal
    Private Const LIMIT As Decimal = 0.1D
    Public Sub New(ByVal theName As String, ByVal curSalary As Decimal)
        m_Name = theName
        m_Salary = curSalary
    End Sub
    ReadOnly Property TheName() As String
        Get
            Return m_Name
        End Get
    End Property
    ReadOnly Property Salary() As Decimal
        Get
            Return m_Salary
        End Get
    End Property
    Public Overloads Sub RaiseSalary(ByVal Percent As Decimal)
        If Percent > LIMIT Then
            'not allowed
            Console.WriteLine("MUST HAVE PASSWORD TO RAISE SALARY MORE THAN LIMIT!!!!")
        Else
            m_Salary = (1 + Percent) * m_Salary
        End If
    End Sub
    Public Overloads Sub RaiseSalary(ByVal Percent As Decimal, _
        ByVal Password As String)
        If Password = "special" Then
            m_Salary = (1 + Percent) * m_Salary
        End If
    End Sub
End Class
