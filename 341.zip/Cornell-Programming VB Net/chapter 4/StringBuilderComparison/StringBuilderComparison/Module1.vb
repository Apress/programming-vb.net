Option Strict On
Module Module1
    Sub Main()
        Console.WriteLine("Please wait calculating with 50000 character strings ....")
        Dim i As Integer
        Dim StartTime As New DateTime()
        Dim EndTime As New DateTime()
        StartTime = DateTime.Now()
        Dim theText As New System.Text.StringBuilder()
        For i = 1 To 50000
            theText = theText.Append("A")
        Next
        EndTime = DateTime.Now
        Dim answer1, answer2 As Long
        answer1 = EndTime.Ticks() - StartTime.Ticks() 'number of 100 nanosecond pulses 
        StartTime = DateTime.Now()
        Dim aString As String
        For i = 1 To 50000
            aString = aString & "A"
        Next
        EndTime = DateTime.Now
        answer2 = (EndTime.Ticks() - StartTime.Ticks()) 'number of 100 nanosecond pulses 
        Console.WriteLine("StringBuilder was " & answer2 / answer1 & " times faster.")
        Console.ReadLine()
    End Sub
End Module
