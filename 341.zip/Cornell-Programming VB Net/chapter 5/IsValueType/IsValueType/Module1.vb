Option Strict On
Module Module1
    Sub Main()
        Dim a As Integer = 3
        Console.WriteLine("a is a value type is " & IsValueType(a))
        Console.ReadLine()
    End Sub
    Function IsValueType(ByVal thing As Object) As Boolean
        Return (TypeOf (thing) Is System.ValueType)
    End Function
End Module
