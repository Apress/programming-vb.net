Option Strict On
Module Module1
  Sub Main()
    Dim tom As New Employee("Tom", 50000, "111-11-1234")
    tom.Address = "901 Grayson"
    Console.Write(tom.TheName & " lives at " & tom.Address)
    Console.ReadLine()
  End Sub
End Module

Public Class Employee
  'since the namespace is PayableEntity, the full name of the class 
  'is PayableEntity.PayableEntity!
  Inherits PayableEntityExample.PayableEntity
  Private m_Name As String
  Private m_Salary As Decimal
  Private m_Address As String
  Private m_TaxID As String
  Private Const LIMIT As Decimal = 0.1D
  Public Sub New(ByVal theName As String, ByVal curSalary As Decimal, ByVal TaxID As String)
    MyBase.New(theName)
    m_Name = theName
    m_Salary = curSalary
    m_TaxID = TaxID
  End Sub
  Public Property Address() As String
    Get
      Return m_Address
    End Get
    Set(ByVal Value As String)
      m_Address = Value
    End Set
  End Property
  Public ReadOnly Property Salary() As Decimal
    Get
      Return m_Salary
    End Get
  End Property
  Public Overrides Property TaxID() As String
    Get
      Return m_TaxID
    End Get
    Set(ByVal Value As String)
      If Value.Length <> 11 Then
        'need to do something here - see Chapter 7
      Else
        m_TaxID = Value
      End If
    End Set
  End Property
End Class
