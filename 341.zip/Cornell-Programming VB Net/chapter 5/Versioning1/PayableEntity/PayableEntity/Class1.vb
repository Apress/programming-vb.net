Imports Microsoft.VisualBasic.ControlChars
Public Class PayableEntity
  Private m_Name As String
  Private m_Address As Address
  Public Sub New(ByVal theName As String, ByVal theAddress As Address)
    m_Name = theName
    m_Address = theAddress
  End Sub
  Public ReadOnly Property TheName() As String
    Get
      Return m_Name
    End Get
  End Property
  Public ReadOnly Property TheAddress()
    Get
      Return m_Address.DisplayAddress
    End Get
  End Property
End Class
Public Class Address
  Private m_Address As String
  Private m_City As String
  Private m_State As String
  Private m_Zip As String
  Public Sub New(ByVal theAddress As String, ByVal theCity As String, _
  ByVal theState As String, ByVal theZip As String)
    m_Address = theAddress
    m_City = theCity
    m_State = theState
    m_Zip = theZip
  End Sub
  Public Function DisplayAddress() As String
    Return m_Address & CrLf & m_City & ", " & m_State _
    & crLF & m_Zip
  End Function
End Class

