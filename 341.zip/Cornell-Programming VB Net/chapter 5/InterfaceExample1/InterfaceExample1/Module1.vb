Option Strict On
Module Module1
  Sub Main()
    Dim tom As New LeadProgrammer("Tom", 50000)
    Dim joe As New Programmer("Joe", 40000)
    Dim theTeam As Programmer() = {tom, joe}
    tom.MyTeam = theTeam
    Console.WriteLine(tom.Rate(joe))
    tom.SpendMoraleFund(100)
    Console.ReadLine()
  End Sub

End Module
Public Interface ILead
  Sub SpendMoraleFund(ByVal amount As Decimal)
  Function Rate(ByVal aPerson As Employee) As String
  Property MyTeam() As Employee()
  Property MoraleFund() As Decimal
End Interface

Public Class LeadProgrammer
  Inherits Programmer
  Implements ILead
  Private m_MoraleFund As Decimal
  Private m_MyTeam As Employee()
  Public Function Rate(ByVal aPerson As Employee) As String _
  Implements ILead.Rate
    Return aPerson.TheName & " rating to be done"
  End Function
  Public Property MyTeam() As Employee() _
  Implements ILead.MyTeam
    Get
      Return m_MyTeam
    End Get
    Set(ByVal Value As Employee())
      m_MyTeam = Value
    End Set
  End Property
  Public Sub SpendMoraleFund(ByVal amount As Decimal) _
  Implements ILead.SpendMoraleFund
    'spend some money
    Console.WriteLine("Spent " & amount.ToString())
  End Sub
  Public Property OurMoraleFund() As Decimal Implements ILead.MoraleFund
    Get
      Return m_MoraleFund
    End Get
    Set(ByVal Value As Decimal)
      m_MoraleFund = Value
    End Set
  End Property
  Public Sub New(ByVal theName As String, ByVal curSalary As Decimal)
    MyBase.New(theName, curSalary)
  End Sub
End Class

Public Class Employee
  Private m_Name As String
  Private m_Salary As Decimal

  Private Const LIMIT As Decimal = 0.1D

  Public Sub New(ByVal theName As String, ByVal curSalary As Decimal)
    m_Name = theName
    m_Salary = curSalary
  End Sub

  Public ReadOnly Property TheName() As String
    Get
      Return m_Name
    End Get
  End Property

  Public ReadOnly Property Salary() As Decimal
    Get
      Return MyClass.m_Salary
    End Get
  End Property

  Public Overridable Overloads Sub RaiseSalary(ByVal Percent As Decimal)
    If Percent > LIMIT Then
      'not allowed
      Console.WriteLine("NEED PASSWORD TO RAISE SALARY MORE " & _
  "THAN LIMIT!!!!")
    Else
      m_Salary = (1 + Percent) * m_Salary
    End If
  End Sub

  Public Overridable Overloads Sub RaiseSalary(ByVal Percent As _
  Decimal, ByVal Password As String)
    If Password = "special" Then
      m_Salary = (1 + Percent) * m_Salary
    End If
  End Sub
End Class
Public Class Programmer
  Inherits Employee
  Public Sub New(ByVal theName As String, ByVal curSalary As Decimal)
    MyBase.New(theName, curSalary)
  End Sub
  Public Overloads Overrides Sub RaiseSalary(ByVal Percent As Decimal)
    MyBase.RaiseSalary(1.2D * Percent, "special")
  End Sub
End Class



