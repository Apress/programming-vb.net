Option Strict On
 Imports System.Windows.Forms
 Module Module1
    Sub Main()
      Dim aForm As New Windows.Forms.Form()
      Dim aType As Type
      aType = aForm.GetType()
      Dim member As Object
      Console.WriteLine("This displays the members of the Form class")
      Console.WriteLine(" Press enter to see the next one.")
      For Each member In aType.GetMembers
        Console.ReadLine()
        Console.Write(member.ToString)
      Next
      Console.WriteLine("Press enter to end")
      Console.ReadLine()
    End Sub
  End Module













































