Option Strict On
Module Module1
  Sub Main()
    Dim tom As New Employee("Tom", 50000)
        Dim sally As New Programmer("Sally", 150000)
        Dim gary As New Archictect("Gary", 150000)
        Dim ourEmployees(2) As Employee
    ourEmployees(0) = tom
        ourEmployees(1) = sally
        ourEmployees(2) = gary
    Dim anEmployee As Employee
    For Each anEmployee In ourEmployees
      anEmployee.RaiseSalary(0.1D)
      Console.WriteLine(anEmployee.TheName & " salary now is " & _
        anEmployee.Salary())
    Next
    Console.ReadLine()
  End Sub
End Module

Public Class Employee
  Private m_Name As String
  Private m_Salary As Decimal

  Private Const LIMIT As Decimal = 0.1D

  Public Sub New(ByVal theName As String, ByVal curSalary As Decimal)
    m_Name = TheName
    m_Salary = curSalary
  End Sub

  Public ReadOnly Property TheName() As String
    Get
      Return m_Name
    End Get
  End Property

  Public ReadOnly Property Salary() As Decimal
    Get
      Return MyClass.m_Salary
    End Get
  End Property

  Public Overridable Overloads Sub RaiseSalary(ByVal Percent As Decimal)
    If Percent > LIMIT Then
      'not allowed
      Console.WriteLine("NEED PASSWORD TO RAISE SALARY MORE " & _
  "THAN LIMIT!!!!")
    Else
      m_Salary = (1 + Percent) * m_Salary
    End If
  End Sub

  Public Overridable Overloads Sub RaiseSalary(ByVal Percent As _
  Decimal, ByVal Password As String)
    If Password = "special" Then
      m_Salary = (1 + Percent) * m_Salary
    End If
  End Sub
End Class
Public Class Programmer
  Inherits Employee
  Public Sub New(ByVal theName As String, ByVal curSalary As Decimal)
    MyBase.New(theName, curSalary)
  End Sub

  Public Overloads Overrides Sub RaiseSalary(ByVal Percent As Decimal)
    MyBase.RaiseSalary(1.2D * Percent, "special")
  End Sub
End Class

Public Class Archictect
    Inherits Programmer
    Public Sub New(ByVal theName As String, ByVal curSalary As Decimal)
        MyBase.New(theName, curSalary)
    End Sub

    Public Overloads Overrides Sub RaiseSalary(ByVal Percent As Decimal)
        MyBase.RaiseSalary(2D * Percent, "special")
    End Sub
End Class


