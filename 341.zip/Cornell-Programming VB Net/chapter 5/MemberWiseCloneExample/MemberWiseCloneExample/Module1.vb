Option Strict On
Module Module1
    Sub Main()
        Dim anArray() As String = {"HELLO"}
        Dim a As New EmbeddedObjects(anArray)
        Console.WriteLine("Am going to display the data in object a now!")
        a.DisplayData()
        Dim b As EmbeddedObjects
        b = a.Clone()
        Dim newData As String = "GOODBYE"
        b.ChangeData(newData)
        Console.WriteLine("Am going to display the data in object b now!")
        b.DisplayData()
        Console.WriteLine("Am going to re-display the data in a" & _
        " after making a change to object b!!!")
        a.DisplayData()
        Console.ReadLine()
    End Sub
End Module

Public Class EmbeddedObjects
    Private m_Data() As String
    Public Sub New(ByVal anArray() As String)
        m_Data = anArray
    End Sub
    Public Sub DisplayData()
        Dim temp As String
        For Each temp In m_Data
            Console.WriteLine(temp)
        Next
    End Sub
    Public Sub ChangeData(ByVal newData As String)
        m_Data(0) = newData
    End Sub
    Public Function Clone() As EmbeddedObjects
        Return CType(Me.MemberwiseClone, EmbeddedObjects)
    End Function
End Class































































