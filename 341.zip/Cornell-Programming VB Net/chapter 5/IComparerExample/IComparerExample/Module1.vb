Option Strict On
Module Module1
  Sub Main()
    Dim tom As New Employee("Tom", 50000)
    Dim sally As New Employee("Sally", 60000)
    Dim Sam As New Employee("Sam", 60000)
    Dim Ted As New Employee("Ted", 50000)
    Dim theEmployees() As Employee = _
    {tom, Sally, Sam, Ted}
    Array.Sort(theEmployees)
    Dim SortingByName As SortByName = New SortByName()
    Array.Sort(theEmployees, SortingByName)
    Dim aEmployee As Employee
    For Each aEmployee In theEmployees
      Console.WriteLine(aEmployee.TheName & " has yearly salary $" _
     & FormatNumber(aEmployee.Salary))
    Next
    Console.ReadLine()
  End Sub
End Module
Public Class SortByName
  Implements IComparer
  Public Function CompareTo(ByVal firstEmp As Object, ByVal _
  secondEmp As Object) As Integer Implements IComparer.Compare
    Dim temp1 As Employee = CType(firstEmp, Employee)
    Dim temp2 As Employee = CType(secondEmp, Employee)
    Return String.Compare(temp1.TheName, temp2.TheName)
  End Function
End Class
Public Class Employee
  Implements IComparable
  Private m_Name As String
  Private m_Salary As Decimal
  Private Const LIMIT As Decimal = 0.1D
  Public Sub New(ByVal theName As String, ByVal curSalary As Decimal)
    m_Name = theName
    m_Salary = curSalary
  End Sub
  Public Function CompareTo(ByVal AnEmployee As Object) As Integer _
  Implements IComparable.CompareTo
    If CType(AnEmployee, Employee).Salary < Me.Salary Then
      Return -1
    ElseIf CType(AnEmployee, Employee).Salary = Me.Salary Then
      Return 0
    ElseIf CType(AnEmployee, Employee).Salary > Me.Salary Then
      Return 1
    End If
  End Function
  Public ReadOnly Property TheName() As String
    Get
      Return m_Name
    End Get
  End Property
  Public ReadOnly Property Salary() As Decimal
    Get
      Return MyClass.m_Salary
    End Get
  End Property
  Public Overridable Overloads Sub RaiseSalary(ByVal Percent As Decimal)
    If Percent > LIMIT Then
      'not allowed
      Console.WriteLine("NEED PASSWORD TO RAISE SALARY MORE " & _
      "THAN LIMIT!!!!")
    Else
      m_Salary = (1 + Percent) * m_Salary
    End If
  End Sub
  Public Overridable Overloads Sub RaiseSalary(ByVal Percent As Decimal, _
    ByVal Password As String)
    If Password = "special" Then
      m_Salary = (1 + Percent) * m_Salary
    End If
  End Sub
End Class


