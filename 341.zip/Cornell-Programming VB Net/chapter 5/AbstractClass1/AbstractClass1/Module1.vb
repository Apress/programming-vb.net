Option Strict On
Module Module1
  Sub Main()
    Dim tom As New Employee("Tom", 50000, "111-11-1234")
    Dim sally As New Programmer("Sally", 150000, "111-11-2234")
    Console.WriteLine(sally.TheName)
    Dim ourEmployees(1) As Employee
    ourEmployees(0) = tom
    ourEmployees(1) = sally
    Dim anEmployee As Employee
    For Each anEmployee In ourEmployees
      anEmployee.RaiseSalary(0.1D)
      Console.WriteLine(anEmployee.TheName & " has tax id " & _
anEmployee.TaxID & ", salary now is " & anEmployee.Salary())
    Next
    Console.ReadLine()
  End Sub
End Module
Public MustInherit Class PayableEntity
  Private m_Name As String
  Public Sub New(ByVal itsName As String)
    m_Name = itsName
  End Sub
  ReadOnly Property TheName() As String
    Get
      Return m_Name
    End Get
  End Property
  Public MustOverride Property TaxID() As String
End Class

Public Class Employee
  Inherits PayableEntity
  Private m_Salary As Decimal
  Private m_TaxID As String
  Private Const LIMIT As Decimal = 0.1D
  Public Sub New(ByVal theName As String, ByVal curSalary As Decimal, _
ByVal TaxID As String)
    MyBase.New(theName)
    m_Salary = curSalary
    m_TaxID = TaxID
  End Sub
  Public Overrides Property TaxID() As String
    Get
      Return m_TaxID
    End Get
    Set(ByVal Value As String)
      If Value.Length <> 11 Then
        'need to do something here - see Chapter 7
      Else
        m_TaxID = Value
      End If
    End Set
  End Property
  ReadOnly Property Salary() As Decimal
    Get
      Return MyClass.m_Salary
    End Get
  End Property
  Public Overridable Overloads Sub RaiseSalary(ByVal Percent As Decimal)
    If Percent > LIMIT Then
      'not allowed
      Console.WriteLine("NEED PASSWORD TO RAISE SALARY MORE " & _
  "THAN LIMIT!!!!")
    Else
      m_Salary = (1D + Percent) * m_Salary
    End If
  End Sub
  Public Overridable Overloads Sub RaiseSalary(ByVal Percent As _
  Decimal, ByVal Password As String)
    If Password = "special" Then
      m_Salary = (1D + Percent) * m_Salary
    End If
  End Sub
End Class
Public Class Programmer
  Inherits Employee
  Private m_gadget As String
  Private m_HowToCallMe As String = "Code guru "
  Public Sub New(ByVal theName As String, ByVal curSalary As Decimal, ByVal taxID As String)
    MyBase.New(theName, curSalary, taxID)
    m_HowToCallMe = m_HowToCallMe & theName
  End Sub
  Public Overloads Overrides Sub RaiseSalary(ByVal Percent As Decimal)
    MyBase.RaiseSalary(1.2D * Percent, "special")
  End Sub
  Public Shadows ReadOnly Property TheName() As String
    Get
      Return m_HowToCallMe
    End Get
  End Property
End Class





