Option Strict On
Public MustInherit Class PayableEntity
    Private m_Name As String
    Public Sub New(ByVal theName As String)
        m_Name = theName
    End Sub
    Public ReadOnly Property TheName() As String
        Get
            Return m_Name
        End Get
    End Property
    Public MustOverride Property TaxID() As String
End Class
