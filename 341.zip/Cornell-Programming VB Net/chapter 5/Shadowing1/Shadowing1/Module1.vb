Option Strict On
Module Module1
  Sub Main()
    Dim tom As New Employee("Tom", 50000)
    Dim sally As New Programmer("Sally", 150000)
    Console.WriteLine(sally.TheName)
    Dim OurEmployees(1) As Employee
    OurEmployees(0) = tom
    OurEmployees(1) = sally
    Dim AnEmployee As Employee
    For Each AnEmployee In OurEmployees
      AnEmployee.RaiseSalary(0.1D)
      Console.WriteLine(AnEmployee.TheName & " salary now is " & _
        AnEmployee.Salary())
    Next
    Console.ReadLine()
  End Sub
End Module

Public Class Employee
  Private m_Name As String
  Private m_Salary As Decimal

  Private Const LIMIT As Decimal = 0.1D

  Public Sub New(ByVal theName As String, ByVal curSalary As Decimal)
    m_Name = theName
    m_Salary = curSalary
  End Sub

  Public ReadOnly Property TheName() As String
    Get
      Return m_Name
    End Get
  End Property

  Public ReadOnly Property Salary() As Decimal
    Get
      Return MyClass.m_Salary
    End Get
  End Property

  Public Overridable Overloads Sub RaiseSalary(ByVal Percent As Decimal)
    If Percent > LIMIT Then
      'not allowed
      Console.WriteLine("NEED PASSWORD TO RAISE SALARY MORE " & _
  "THAN LIMIT!!!!")
    Else
      m_Salary = (1 + Percent) * m_Salary
    End If
  End Sub

  Public Overridable Overloads Sub RaiseSalary(ByVal Percent As _
  Decimal, ByVal Password As String)
    If Password = "special" Then
      m_Salary = (1 + Percent) * m_Salary
    End If
  End Sub
End Class
Public Class Programmer
  Inherits Employee
  Private m_gadget As String
  Private m_HowToCallMe As String = "Code guru "
  Public Sub New(ByVal theName As String, ByVal curSalary As Decimal)
    MyBase.New(theName, curSalary)
    m_HowToCallMe = m_HowToCallMe & theName
  End Sub
  Public Overloads Overrides Sub RaiseSalary(ByVal Percent As Decimal)
    MyBase.RaiseSalary(1.2D * Percent, "special")
  End Sub
  Public Shadows ReadOnly Property TheName() As String
    Get
      Return m_HowToCallMe
    End Get
  End Property
End Class




