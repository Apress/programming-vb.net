Imports Microsoft.VisualBasic.ControlChars
Module Module1
  Sub Main()
    Dim myDerived As New Derived()
    myDerived.DisplayIt()
    Console.ReadLine()
  End Sub
End Module
Public Class Parent
  Public Const MY_STRING As String = "this is a test"
  Public Overridable Sub DisplayIt()
    Console.WriteLine(MY_STRING)
  End Sub
End Class
Public Class Derived
  Inherits Parent
  Public Overrides Sub DisplayIt()
    Console.WriteLine(ParseIt(MyBase.MY_STRING))
  End Sub
  Public Function ParseIt(ByVal aString As String)
    Dim tokens() As String
    tokens = aString.Split(Chr(32)) 'actually split defaults to splitting on spaces
    Dim temp As String
    'rejoin them into one string adding a CR/LF betweeen the words
    temp = Join(tokens, CrLf)
    Return temp
  End Function
End Class


