Option Strict On
Module Module1
    Sub Main()
        Dim tom As New Employee("Tom", 50000)
        Dim sally As New Employee("Sally", 60000)
        Dim myEmployees As New Employees()
        Console.WriteLine(tom.ToString)
        myEmployees.Add(tom)
        myEmployees.Add(sally)
        ' myEmployees.Add("Tom")
        Dim aEmployee As Employee
        For Each aEmployee In myEmployees
            Console.WriteLine(aEmployee.TheName)
        Next
        Console.ReadLine()
    End Sub


End Module
Public Class Employees
    Inherits System.Collections.CollectionBase
    ' Restricts to adding only Employee items
    ' delegating to the internal List object's Add method
    Public Sub Add(ByVal aEmployee As Employee)
        List.Add(aEmployee)
    End Sub
    Public Sub Remove(ByVal index As Integer)
        If index > Count - 1 Or index < 0 Then
            ' outside the range, should throw an exception (Chapter 7)
            ' haven't shown you that so we display a message box 
            MsgBox("Can't add this item")
        Else
            List.RemoveAt(index)
        End If
    End Sub

    Default Public ReadOnly Property Item(ByVal index As Integer) As Employee
        Get
            Return CType(List.Item(index), Employee)
        End Get
    End Property
End Class























Public Class Employee
    Private m_Name As String
    Private m_Salary As Decimal

    Private Const LIMIT As Decimal = 0.1D

    Public Sub New(ByVal theName As String, ByVal curSalary As Decimal)
        m_Name = theName
        m_Salary = curSalary
    End Sub

    Public ReadOnly Property TheName() As String
        Get
            Return m_Name
        End Get
    End Property

    Public ReadOnly Property Salary() As Decimal
        Get
            Return MyClass.m_Salary
        End Get
    End Property

    Public Overridable Overloads Sub RaiseSalary(ByVal Percent As Decimal)
        If Percent > LIMIT Then
            'not allowed
            Console.WriteLine("NEED PASSWORD TO RAISE SALARY MORE " & _
        "THAN LIMIT!!!!")
        Else
            m_Salary = (1 + Percent) * m_Salary
        End If
    End Sub

    Public Overridable Overloads Sub RaiseSalary(ByVal Percent As _
    Decimal, ByVal Password As String)
        If Password = "special" Then
            m_Salary = (1 + Percent) * m_Salary
        End If
    End Sub
End Class
