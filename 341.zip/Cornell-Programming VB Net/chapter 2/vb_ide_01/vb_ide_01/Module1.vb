Module Module1
    
    Sub Main()
    Console.WriteLine("testing 1 2 3")
    BadFunction()
    End Sub
    
End Module
