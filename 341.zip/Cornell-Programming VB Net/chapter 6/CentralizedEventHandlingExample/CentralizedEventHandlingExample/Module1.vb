Option Strict On
Module Module1
  Private m_EventGenerator As EventGenerator
  Sub Main()
    m_EventGenerator = New EventGenerator()
    Dim commandLines() As String = System.Environment.GetCommandLineArgs
    If commandLines.Length = 1 Then
      MsgBox("No command argument, program ending!")
      Environment.Exit(-1)
    Else
      Dim theCommand As String = commandLines(1)
      Console.WriteLine("The command line option is " & theCommand)
      'check the command line parameter and set the 
      'handler accordingly
      Select Case theCommand
        Case "first"
          AddHandler m_EventGenerator.TestEvent, _
    AddressOf m_EventGenerator_TestEvent1
        Case "second"
          AddHandler m_EventGenerator.TestEvent, _
    AddressOf m_EventGenerator_TestEvent2
        Case Else
          AddHandler m_EventGenerator.TestEvent, _
    AddressOf m_EventGenerator_TestEventDefault
      End Select
      'fire the events
      m_EventGenerator.TriggerEvents()
    End If
    Console.WriteLine("Press enter to end.")
    Console.ReadLine()
  End Sub
  'default event handler for non-empty command line
  Public Sub m_EventGenerator_TestEventDefault( _
ByVal sender As Object, ByVal evt As EventArgs)
    System.Console.WriteLine("Default choice " & _
m_EventGenerator.GetDescription())
  End Sub
  'event handler #2 for string "first"
  Public Sub m_EventGenerator_TestEvent1( _
ByVal sender As Object, ByVal evt As EventArgs)
    System.Console.WriteLine("1st choice " & _
m_EventGenerator.GetDescription())
  End Sub
  'event handler #3 for string "second"
  Public Sub m_EventGenerator_TestEvent2( _
ByVal sender As Object, ByVal evt As EventArgs)
    System.Console.WriteLine("2nd choice " & _
m_EventGenerator.GetDescription())
  End Sub
End Module

Public Class EventGenerator
  'the one and only event in our class
  Public Event TestEvent(ByVal sender As Object, _
ByVal evt As EventArgs)

  'could allow a default constructor instead
  Public Sub New()
    'no constructor code
  End Sub

  Public Function GetDescription() As String
    Return "EventGenerator class"
  End Function
  'will be called to trigger demo events
  Public Sub TriggerEvents()
    Dim e As System.EventArgs = New System.EventArgs()
    RaiseEvent TestEvent(Me, e)
  End Sub
End Class
