Option Strict On
Public Class DelegateServer
  Public Delegate Sub ClientCallback(ByVal lngVal As Long)
  Private m_Clients As ClientCallback
  'allow default constructor so no Public Sub New()
  Public Sub RegisterDelegate(ByVal aDelegate As _
  ClientCallback, ByVal doIt As Boolean)
    'would normally have serious validation code here
    'register the callback only if True is passe as second parameter 
    If doIt Then
      m_Clients = CType(System.Delegate.Combine(m_Clients, aDelegate), _
      ClientCallback)
    End If
  End Sub
  Public Sub CallClients(ByVal lngVal As Long)
    m_Clients(lngVal)
  End Sub
End Class
Module Module1
  Sub Main()
    Dim delsrv As New DelegateServer()
    delsrv.RegisterDelegate(AddressOf DelegateCallbackHandler1, True)

    'won't be called because of False as second parameter!
    delsrv.RegisterDelegate(AddressOf DelegateCallbackHandler2, False)

    'trigger the server to call the acceptable clients
    delsrv.CallClients(125)
    Console.WriteLine("Press enter to end.")
    Console.ReadLine()
  End Sub
  Public Sub DelegateCallbackHandler1(ByVal lngVal As Long)
    System.Console.WriteLine("DelegateCallbackHandler1 called")
  End Sub
  Public Sub DelegateCallbackHandler2(ByVal lngVal As Long)
    System.Console.WriteLine("DelegateCallbackHandler2 called")
  End Sub
End Module


