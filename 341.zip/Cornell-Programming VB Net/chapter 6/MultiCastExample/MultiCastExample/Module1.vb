Option Strict On
Module Module1
  Sub Main()
    Console.WriteLine("Calling delegate function...")
    RegisterDelegate(AddressOf CallBackHandler1)
    RegisterDelegate(AddressOf CallBackHandler2)
    CallDelegates()
    Console.WriteLine( _
  "Finished calling delegate function...")
    Console.ReadLine()
  End Sub
  Public Sub CallBackHandler1(ByVal lngVal As RETURN_VALUES)
    Console.WriteLine("Callback 1 returned " & lngVal)
  End Sub
  Public Sub CallBackHandler2(ByVal lngVal As RETURN_VALUES)
    Console.WriteLine("Callback 2 returned " & lngVal)
  End Sub
End Module

Module Module2
  Public Delegate Sub CallBackFunc(ByVal lngVal As RETURN_VALUES)
  Private m_cbFunc As CallBackFunc
  Public Enum RETURN_VALUES
    VALUE_SUCCESS
    VALUE_FAILURE
  End Enum
  Public Sub RegisterDelegate(ByRef cbFunc As CallBackFunc)
    m_cbFunc = CType(System.Delegate.Combine( _
m_cbFunc, cbFunc), CallBackFunc)
  End Sub
  Public Sub CallDelegates()
    Dim lngCounter As Long = 0
    'call back the callers through their delegate 
    'return success
    m_cbFunc(RETURN_VALUES.VALUE_SUCCESS)
  End Sub
End Module
