Option Strict On
Module Module1
  Sub Main()
    Dim test() As String = {"Mike Iem", "Dave Mendlen", "Alan Carter", _
    "Tony Goodhew", "Ari Bixhorn", "Susan Warren"}
    'declare the callback variable: ClassName.DelegateName
    Dim MyCallBack As SpecialSort.SpecialCompareCallback
    MyCallBack = AddressOf MyCustomCompare.TheBasicCompare
    SpecialSort.MySort(test, MyCallBack)
    Console.WriteLine("Here is a basic sort by FIRST name")
    Dim temp As String
    For Each temp In test
      Console.WriteLine(temp)
    Next
    'send a different compare routine
    MyCallBack = AddressOf MyCustomCompare.TheSpecialCompare
    SpecialSort.MySort(test, MyCallBack)
    Console.WriteLine()
    Console.WriteLine("Here is a sort by LAST name")
    For Each temp In test
      Console.WriteLine(temp)
    Next
    Console.ReadLine()
  End Sub
End Module
Public Class SpecialSort
  Public Delegate Function SpecialCompareCallback(ByVal firstString _
  As String, ByVal secondString As String) As Boolean

  Public Shared Sub MySort(ByVal Stuff As String(), _
  ByVal MyCompare As SpecialCompareCallback)
    Dim i, j As Integer
    Dim temp As String
    Dim bottom As Integer = Stuff.GetLowerBound(0)
    Dim top As Integer = Stuff.GetUpperBound(0)
    For i = bottom To (top - bottom)
      For j = i + 1 To top
        If MyCompare(Stuff(j), Stuff(i)) Then
          temp = Stuff(i)
          Stuff(i) = Stuff(j)
          Stuff(j) = temp
        End If
      Next j
    Next i
  End Sub
End Class
Public Class MyCustomCompare
  Public Shared Function TheBasicCompare(ByVal firstString As String, _
  ByVal secondString As String) As Boolean
    Return (firstString <= secondString)
  End Function
  Public Shared Function TheSpecialCompare(ByVal firstString As String, _
  ByVal secondString As String) As Boolean
    Dim tokens1, tokens2 As String()
    tokens1 = firstString.Split(Chr(32))
    tokens2 = secondString.Split(Chr(32))
    Return (tokens1(1) <= tokens2(1)) ' compare on last name!
  End Function
End Class



