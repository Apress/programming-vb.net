Option Strict On
Module Module1
    Public Delegate Sub StringSubDelegate(ByVal aString As String)
    Sub Main()
        Dim test As New ClassForStringSubDelegate()
        Dim aDelegate As StringSubDelegate
        aDelegate = AddressOf test.TestMsgBox
        aDelegate("Hello")
        Console.ReadLine()
    End Sub
End Module
Public Class ClassForStringSubDelegate
    'live with the default constructor
    Public Sub TestSub(ByVal aString As String)
        Console.WriteLine(aString & aString)
    End Sub

    Public Sub TestMsgBox(ByVal aString As String)
        MsgBox(aString & aString)
    End Sub
End Class
