Option Strict On
Module Module1
  Private WithEvents anEmployee As EmployeeWithEvents
  Sub Main()
    Dim tom As New EmployeeWithEvents("Tom", 100000)
    Console.WriteLine(tom.TheName & "  has salary " & tom.Salary)
    AddHandler tom.SalarySecurityEvent, _
    AddressOf anEmployee_SalarySecurityEvent
    tom.RaiseSalary(0.2D) 'D necessary for decimal
    Console.WriteLine(tom.TheName & " still has salary " & tom.Salary)
    Console.WriteLine("Please press the Enter key")
    Console.ReadLine()
  End Sub
  Public Sub anEmployee_SalarySecurityEvent(ByVal Sender _
      As AddHandlerExample1.EmployeeWithEvents, _
      ByVal e As AddHandlerExample1.ImproperSalaryRaiseEvent) _
      Handles anEmployee.SalarySecurityEvent
    MsgBox(Sender.TheName & " had an improper salary raise of " & _
    FormatPercent(e.theRaise) & " with INCORRECT PASSWORD!")
  End Sub
End Module


Public Class EmployeeWithEvents
  Private m_Name As String
  Private m_Salary As Decimal
  Private Const LIMIT As Decimal = 0.1D
  Public Event SalarySecurityEvent(ByVal Sender As _
     AddHandlerExample1.EmployeeWithEvents, _
     ByVal e As ImproperSalaryRaiseEvent)

  Public Sub New(ByVal sName As String, ByVal curSalary As Decimal)
    m_Name = sName
    m_Salary = curSalary
  End Sub
  ReadOnly Property TheName() As String
    Get
      Return m_Name
    End Get
  End Property
  ReadOnly Property Salary() As Decimal
    Get
      Return m_Salary
    End Get
  End Property
  Public Overloads Sub RaiseSalary(ByVal Percent As Decimal)
    If Percent > LIMIT Then
      'not allowed
      RaiseEvent SalarySecurityEvent(Me, _
 New ImproperSalaryRaiseEvent(Percent, "INCORRECT PASSWORD!"))
    Else
      m_Salary = (1 + Percent) * m_Salary
    End If
  End Sub
  Public Overloads Sub RaiseSalary(ByVal Percent As Decimal, _
    ByVal Password As String)
    If Password = "special" Then
      m_Salary = (1 + Percent) * m_Salary
    End If
  End Sub
End Class
Public Class ImproperSalaryRaiseEvent
  Inherits System.EventArgs
  Private m_Message As String
  Private m_theRaise As Decimal
  Sub New(ByVal theRaise As Decimal, ByVal theReason As String)
    MyBase.New()
    m_Message = theReason
    m_theRaise = theRaise
  End Sub
  ReadOnly Property Message() As String
    Get
      Return m_Message
    End Get
  End Property

  ReadOnly Property theRaise() As Decimal
    Get
      Return m_theRaise
    End Get
  End Property
End Class



