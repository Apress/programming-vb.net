Option Strict On
Imports System.IO
Module Module1
  Sub Main()
    Dim i As Integer
    Dim theBytes(255) As Byte
    For i = 0 To 255
      theBytes(i) = CByte(i)
    Next
    Dim myFileStream As FileStream
    Try
      myFileStream = New FileStream("C:\foo", _
  FileMode.OpenOrCreate, FileAccess.Write)
      myFileStream.Write(theBytes, 0, 256)
    Finally
      If Not (myFileStream Is Nothing) Then myFileStream.Close()
    End Try
    DisplayAFile("C:\foo")
    Console.ReadLine()
  End Sub
  Sub DisplayAFile(ByVal theFileName As String)
    Dim theFile As FileStream
    Dim i As Long
    Try
      theFile = New FileStream(theFileName, _
FileMode.Open, FileAccess.Read)
      For i = 0 To (theFile.Length - 1) 'one less since count starts at 0
        Console.Write(theFile.ReadByte)
      Next
    Catch e As Exception
      Throw e
    Finally
      If Not (theFile Is Nothing) Then theFile.Close()
    End Try
  End Sub

End Module

