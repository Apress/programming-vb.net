Option Strict On
Imports System.IO
Public Class Form1
  Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

  Public Sub New()
    MyBase.New()

    'This call is required by the Windows Form Designer.
    InitializeComponent()

    'Add any initialization after the InitializeComponent() call

  End Sub

  'Form overrides dispose to clean up the component list.
  Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
    If disposing Then
      If Not (components Is Nothing) Then
        components.Dispose()
      End If
    End If
    MyBase.Dispose(disposing)
  End Sub
  Friend WithEvents Button1 As System.Windows.Forms.Button
  Friend WithEvents ListBox1 As System.Windows.Forms.ListBox
  Friend WithEvents Label1 As System.Windows.Forms.Label
  Friend WithEvents TextBox1 As System.Windows.Forms.TextBox

  'Required by the Windows Form Designer
  Private components As System.ComponentModel.Container

  'NOTE: The following procedure is required by the Windows Form Designer
  'It can be modified using the Windows Form Designer.  
  'Do not modify it using the code editor.
  <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
    Me.Label1 = New System.Windows.Forms.Label()
    Me.Button1 = New System.Windows.Forms.Button()
    Me.ListBox1 = New System.Windows.Forms.ListBox()
    Me.TextBox1 = New System.Windows.Forms.TextBox()
    Me.SuspendLayout()
    '
    'Label1
    '
    Me.Label1.Location = New System.Drawing.Point(16, 24)
    Me.Label1.Name = "Label1"
    Me.Label1.Size = New System.Drawing.Size(264, 24)
    Me.Label1.TabIndex = 2
    Me.Label1.Text = "Directory?"
    '
    'Button1
    '
    Me.Button1.Location = New System.Drawing.Point(32, 328)
    Me.Button1.Name = "Button1"
    Me.Button1.Size = New System.Drawing.Size(280, 32)
    Me.Button1.TabIndex = 0
    Me.Button1.Text = "Show hidden files"
    '
    'ListBox1
    '
    Me.ListBox1.HorizontalScrollbar = True
    Me.ListBox1.ItemHeight = 16
    Me.ListBox1.Location = New System.Drawing.Point(24, 56)
    Me.ListBox1.Name = "ListBox1"
    Me.ListBox1.ScrollAlwaysVisible = True
    Me.ListBox1.Size = New System.Drawing.Size(280, 244)
    Me.ListBox1.TabIndex = 1
    '
    'TextBox1
    '
    Me.TextBox1.Anchor = System.Windows.Forms.AnchorStyles.None
    Me.TextBox1.Location = New System.Drawing.Point(104, 24)
    Me.TextBox1.Name = "TextBox1"
    Me.TextBox1.Size = New System.Drawing.Size(200, 22)
    Me.TextBox1.TabIndex = 3
    Me.TextBox1.Text = ""
    '
    'Form1
    '
    Me.AutoScaleBaseSize = New System.Drawing.Size(6, 15)
    Me.ClientSize = New System.Drawing.Size(328, 384)
    Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.TextBox1, Me.Label1, Me.ListBox1, Me.Button1})
    Me.Name = "Form1"
    Me.Text = "Show hidden files"
    Me.ResumeLayout(False)

  End Sub

#End Region
  Private Sub Button1_Click(ByVal sender As System.Object, _
    ByVal e As System.EventArgs) Handles Button1.Click
    Me.Cursor = System.Windows.Forms.Cursors.WaitCursor
    ListBox1.Items.Clear()
    WorkWithDirectory(New DirectoryInfo(TextBox1.Text))
    Me.Cursor = System.Windows.Forms.Cursors.Default
  End Sub
  Public Sub WorkWithDirectory(ByVal aDir As DirectoryInfo)
    Dim nextDir As DirectoryInfo
    Try
      WorkWithFilesInDir(aDir)
      For Each nextDir In aDir.GetDirectories
        WorkWithDirectory(nextDir)
      Next
    Catch e As Exception
      MsgBox(e.Message & vbCrLf & e.StackTrace)
    End Try
  End Sub
  Public Sub WorkWithFilesInDir(ByVal aDir As DirectoryInfo)
    Dim aFile As FileInfo
    For Each aFile In aDir.GetFiles()
            If (aFile.Attributes And FileAttributes.Hidden) = FileAttributes.Hidden Then
                ListBox1.Items.Add("FOUND hidden file named " & aFile.FullName)
            End If
        Next
  End Sub

  Private Sub ListBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListBox1.SelectedIndexChanged

  End Sub

  Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

  End Sub
End Class
