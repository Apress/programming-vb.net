Option Strict On
Imports System.IO
Module Module1

  Sub Main()
    Dim myFileStream As New FileStream("MyFile.txt", _
    FileMode.OpenOrCreate, FileAccess.Write)
  End Sub

End Module
