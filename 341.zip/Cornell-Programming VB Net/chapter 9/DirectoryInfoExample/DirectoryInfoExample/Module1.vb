Option Strict On
Imports System.IO
Module Module1
  Sub Main()
    Dim myDirectory As DirectoryInfo
    Try
            myDirectory = New DirectoryInfo("C:\")
      Dim aFile As FileInfo
      For Each aFile In myDirectory.GetFiles
        Console.WriteLine("The file named " & aFile.FullName & _
        " has length " & aFile.Length)
      Next
    Catch e As Exception
      MsgBox("eeks  - an exception " & e.StackTrace)
    Finally
      Console.WriteLine("Press enter to end")
      Console.ReadLine()
    End Try
  End Sub
End Module

