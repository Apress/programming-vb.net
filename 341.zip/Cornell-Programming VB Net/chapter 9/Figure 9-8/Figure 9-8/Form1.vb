Option Strict On
Imports System.IO
Public Class Form1
  Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

  Public Sub New()
    MyBase.New()

    'This call is required by the Windows Form Designer.
    InitializeComponent()

    'Add any initialization after the InitializeComponent() call

  End Sub

  'Form overrides dispose to clean up the component list.
  Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
    If disposing Then
      If Not (components Is Nothing) Then
        components.Dispose()
      End If
    End If
    MyBase.Dispose(disposing)
  End Sub
  Friend WithEvents btnStart As System.Windows.Forms.Button
  Friend WithEvents FileSystemWatcher1 As System.IO.FileSystemWatcher
  Friend WithEvents Label1 As System.Windows.Forms.Label
  Friend WithEvents txtDirectory As System.Windows.Forms.TextBox
  Friend WithEvents chkRecursive As System.Windows.Forms.CheckBox
  
  'Required by the Windows Form Designer
  Private components As System.ComponentModel.Container

  'NOTE: The following procedure is required by the Windows Form Designer
  'It can be modified using the Windows Form Designer.  
  'Do not modify it using the code editor.
  <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
    Me.Label1 = New System.Windows.Forms.Label()
    Me.FileSystemWatcher1 = New System.IO.FileSystemWatcher()
    Me.txtDirectory = New System.Windows.Forms.TextBox()
    Me.btnStart = New System.Windows.Forms.Button()
    Me.chkRecursive = New System.Windows.Forms.CheckBox()
    CType(Me.FileSystemWatcher1, System.ComponentModel.ISupportInitialize).BeginInit()
    Me.SuspendLayout()
    '
    'Label1
    '
    Me.Label1.Location = New System.Drawing.Point(8, 16)
    Me.Label1.Name = "Label1"
    Me.Label1.Size = New System.Drawing.Size(72, 32)
    Me.Label1.TabIndex = 1
    Me.Label1.Text = "Directory?"
    '
    'FileSystemWatcher1
    '
    Me.FileSystemWatcher1.EnableRaisingEvents = True
    Me.FileSystemWatcher1.NotifyFilter = ((System.IO.NotifyFilters.FileName Or System.IO.NotifyFilters.DirectoryName) _
                Or System.IO.NotifyFilters.LastWrite)
    Me.FileSystemWatcher1.SynchronizingObject = Me
    '
    'txtDirectory
    '
    Me.txtDirectory.Location = New System.Drawing.Point(114, 16)
    Me.txtDirectory.Name = "txtDirectory"
    Me.txtDirectory.Size = New System.Drawing.Size(160, 22)
    Me.txtDirectory.TabIndex = 2
    Me.txtDirectory.Text = ""
    '
    'btnStart
    '
    Me.btnStart.Location = New System.Drawing.Point(62, 216)
    Me.btnStart.Name = "btnStart"
    Me.btnStart.Size = New System.Drawing.Size(168, 32)
    Me.btnStart.TabIndex = 0
    Me.btnStart.Text = "Start watching!"
    '
    'chkRecursive
    '
    Me.chkRecursive.Location = New System.Drawing.Point(16, 64)
    Me.chkRecursive.Name = "chkRecursive"
    Me.chkRecursive.TabIndex = 3
    Me.chkRecursive.Text = "Recursive?"
    '
    'Form1
    '
    Me.AutoScaleBaseSize = New System.Drawing.Size(6, 15)
    Me.ClientSize = New System.Drawing.Size(292, 268)
    Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.chkRecursive, Me.txtDirectory, Me.Label1, Me.btnStart})
    Me.Name = "Form1"
    Me.Text = "Start file system monitoring"
    CType(Me.FileSystemWatcher1, System.ComponentModel.ISupportInitialize).EndInit()
    Me.ResumeLayout(False)

  End Sub

#End Region

  Private Sub btnStart_Click(ByVal sender As System.Object, _
 ByVal e As System.EventArgs) Handles btnStart.Click
    If CheckPath() Then
      FileSystemWatcher1.Path = txtDirectory.Text
      If chkRecursive.Checked Then
        FileSystemWatcher1.IncludeSubdirectories = True
      Else
        FileSystemWatcher1.IncludeSubdirectories = False
      End If
      FileSystemWatcher1.EnableRaisingEvents = True
    End If
  End Sub
  Function CheckPath() As Boolean
    If Directory.Exists(txtDirectory.Text) Then
      Return (True)
    Else
      txtDirectory.Text = ""
      txtDirectory.Focus()
      MsgBox("No directory by that name exists!")
      Return False
    End If
  End Function
  Private Sub FileSystemWatcher1_Changed(ByVal sender As Object, _
  ByVal e As System.IO.FileSystemEventArgs) Handles _
  FileSystemWatcher1.Changed
    MsgBox(txtDirectory.Text & " has changed!")
  End Sub

  Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

  End Sub
End Class
