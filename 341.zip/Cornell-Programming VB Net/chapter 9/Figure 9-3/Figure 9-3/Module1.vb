Option Strict On
Imports System.io
Module Module1
  Sub Main()
    WriteData()
  End Sub
  Sub WriteData()
    Dim aFileStream As FileStream
    Try
      aFileStream = New FileStream("c:\data.txt", FileMode.OpenOrCreate, _
        FileAccess.Write)
      Dim myBinaryWriter As New BinaryWriter(aFileStream)
      myBinaryWriter.Write("Hello world")
      myBinaryWriter.Write(1)
    Catch e As Exception
      Console.WriteLine(e.StackTrace)
    Finally
      If Not (aFileStream Is Nothing) Then aFileStream.Close()
    End Try
  End Sub
End Module
