Option Strict On
'uses the System.Runtime.Serialization.Formatters.Soap assembly
Imports System.IO
Imports System.Runtime.Serialization
Imports System.Runtime.Serialization.Formatters.soap
Module Module1
  Sub Main()
    Dim Sally As New Manager("Sally", 150000)
    Dim Tom As Secretary
    Tom = New Secretary("Tom", 100000, Sally)
    Sally.MySecretary = Tom

    Dim Employees As New ArrayList()
    Employees.Add(Tom)
    Employees.Add(Sally)

    Console.WriteLine(Tom.TheName & " is employee " & _
    Tom.TheID & " and has salary " & Tom.Salary)
    Console.WriteLine("Tom's boss is " & Tom.MyManager.TheName)
    Console.WriteLine("Sally's secretary is " & Sally.MySecretary.TheName)
    Console.WriteLine()
    Console.WriteLine(Sally.TheName & " is employee " & _
    Sally.TheID & " has salary " & Sally.Salary)
    Sally.RaiseSalary(0.1D)
    Console.WriteLine("After raise " & Sally.TheName & " has salary " & Sally.Salary)
    SerializeToSoap(Employees, "C:\test.xml")
    Console.WriteLine("Serializing and clearing employee array list!")
    Console.WriteLine()
    Employees.Clear()

    Console.WriteLine("DeSerializing and restoring employee array list!")
    Employees = DeSerializeFromSoap("C:\test.xml")
    Tom = CType(Employees(0), Secretary)
    Sally = CType(Employees(1), Manager)

    'Check that state was restored
    Console.WriteLine(Tom.TheName & " is employee " & _
    Tom.TheID & " and has salary " & Tom.Salary)
    Console.WriteLine("Tom's boss is " & Tom.MyManager.TheName)
    Console.WriteLine("Sally's secretary is " & Sally.MySecretary.TheName)
    Console.WriteLine()
    Console.WriteLine(Sally.TheName & " is employee " & _
    Sally.TheID & " has salary " & Sally.Salary)

    'check that functionality was restored
    Sally.RaiseSalary(0.1D)
    Console.WriteLine("After raise " & Sally.TheName & " has salary " _
      & Sally.Salary)
    Console.ReadLine()
  End Sub

  Sub SerializeToSoap(ByVal myEmployees As ArrayList, ByVal fName As String)
    Dim fStream As FileStream
    Dim mySoapFormatter As New Formatters.Soap.SoapFormatter()
    Try
      fStream = New FileStream(fName, FileMode.Create, FileAccess.Write)
      mySoapFormatter.Serialize(fStream, myEmployees)
    Catch
      Throw
    Finally
      If Not (fStream Is Nothing) Then fStream.Close()
    End Try
  End Sub

  Function DeSerializeFromSoap(ByVal fName As String) As ArrayList
    Dim fStream As New FileStream(fName, FileMode.Open, FileAccess.Read)
    Dim mySoapFormatter As New Formatters.Soap.SoapFormatter()
    Try
      fStream = New FileStream(fName, FileMode.Open, FileAccess.Read)
      Return CType(mySoapFormatter.Deserialize(fStream), ArrayList)
    Catch
      Throw
    Finally
      If Not (fStream Is Nothing) Then fStream.Close()
    End Try
  End Function

End Module
<Serializable()> Public Class Employee
  Private m_Name As String
  Private m_Salary As Decimal
  Private Const LIMIT As Decimal = 0.1D
  Private Shared m_EmployeeId As Integer = 1000
  Private m_myID As Integer
  Public Sub New(ByVal sName As String, ByVal curSalary As Decimal)
    m_Name = sName
    m_Salary = curSalary
    m_myID = m_EmployeeId
    m_EmployeeId = m_EmployeeId + 1
  End Sub
  ReadOnly Property TheID() As Integer
    Get
      Return m_myID
    End Get
  End Property
  ReadOnly Property TheName() As String
    Get
      Return m_Name
    End Get
  End Property
  ReadOnly Property Salary() As Decimal
    Get
      Return MyClass.m_Salary
    End Get
  End Property
  Public Overridable Overloads Sub RaiseSalary(ByVal Percent As Decimal)
    If Percent > LIMIT Then
      'not allowed
      Console.WriteLine("MUST HAVE PASSWORD TO RAISE SALARY MORE THAN LIMIT!!!!")
    Else
      m_Salary = (1 + Percent) * m_Salary
    End If
  End Sub
  Public Overridable Overloads Sub RaiseSalary(ByVal Percent As Decimal, _
      ByVal Password As String)
    If Password = "special" Then
      m_Salary = (1 + Percent) * m_Salary
    End If
  End Sub
End Class
<Serializable()> Public Class Manager
  Inherits Employee
  Private m_Sec As Secretary
  Private m_Salary As Decimal
  Public Sub New(ByVal sName As String, ByVal curSalary As Decimal)
    MyBase.New(sName, curSalary)
  End Sub
  Public Sub New(ByVal sName As String, ByVal curSalary As Decimal, _
      ByVal mySec As Secretary)
    MyBase.New(sName, curSalary)
    m_Sec = mySec
  End Sub
  Property MySecretary() As Secretary
    Get
      Return m_Sec
    End Get
    Set(ByVal Value As Secretary)
      m_Sec = Value
    End Set
  End Property
  Public Overloads Overrides Sub RaiseSalary(ByVal percent As Decimal)
    MyBase.RaiseSalary(2 * percent, "special")
  End Sub
End Class
<Serializable()> Public Class Secretary
  Inherits Employee
  Private m_Boss As Manager
  Public Sub New(ByVal sName As String, ByVal curSalary As Decimal, _
      ByVal myBoss As Manager)
    MyBase.New(sName, curSalary)
    m_Boss = myBoss
  End Sub
  Property MyManager() As Manager
    Get
      Return m_Boss
    End Get
    Set(ByVal Value As Manager)
      m_Boss = Value
    End Set
  End Property
End Class


