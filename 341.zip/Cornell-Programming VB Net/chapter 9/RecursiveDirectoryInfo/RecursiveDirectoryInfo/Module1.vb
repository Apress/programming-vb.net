Option Strict On
Imports System.IO
Module Module1
  Sub Main()
    Dim nameOfDirectory As String = "C:\"
    Dim myDirectory As DirectoryInfo
    myDirectory = New DirectoryInfo(nameOfDirectory)
    WorkWithDirectory(myDirectory)
  End Sub
  Public Sub WorkWithDirectory(ByVal aDir As DirectoryInfo)
    Dim nextDir As DirectoryInfo
    WorkWithFilesInDir(aDir)
    For Each nextDir In aDir.GetDirectories
      WorkWithDirectory(nextDir)
    Next
  End Sub
  Public Sub WorkWithFilesInDir(ByVal aDir As DirectoryInfo)
    Dim aFile As FileInfo
    For Each aFile In aDir.GetFiles()
      'do what you want with the file
      'here we simply list the full path name
      Console.WriteLine(aFile.FullName)
    Next
  End Sub
End Module
