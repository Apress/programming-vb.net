Option Strict On
Imports System.IO
Module Module1

  Sub Main()
    Dim curDir, nextDir As String
    Try
      curDir = Directory.GetCurrentDirectory()
      Console.WriteLine(curDir)
      For Each nextDir In Directory.GetDirectories(curDir)
        Console.WriteLine(nextDir)
      Next
    Catch ioe As IOException
      Console.WriteLine("eeeks - i/o problems!" & ioe.Message)
    Catch e As Exception
      Console.Write(e.StackTrace)
    Finally
      Console.ReadLine()
    End Try
  End Sub
End Module

