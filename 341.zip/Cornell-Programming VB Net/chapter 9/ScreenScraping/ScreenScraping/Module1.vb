'Call AmazonRanker by passing ISBN into New
Option Strict On
Imports System.IO
Imports System.Net
Module Module1
  Sub Main()
    Dim myBook As New AmazonRanker("1893115992")
        Console.WriteLine("Getting Amazon rank for ISBN # 1893115992")
        MsgBox("This book's current rank is " & myBook.GetRank)
  End Sub
End Module

Public Class AmazonRanker
  Private m_URL As String
  Private m_Rank As Integer
  Public Sub New(ByVal ISBN As String)
    m_URL = "http://www.amazon.com/exec/obidos/ASIN/" & ISBN
  End Sub

  Public ReadOnly Property GetRank() As Integer
    Get
      Return ScrapeAmazon()
    End Get
  End Property

  Private Function ScrapeAmazon() As Integer
    Try
      Dim theURL As New Uri(m_URL)
      Dim theRequest As WebRequest
      theRequest = WebRequest.Create(theURL)
      Dim theResponse As WebResponse
      theResponse = theRequest.GetResponse
      Dim aReader As New StreamReader(theResponse.GetResponseStream())
      Dim theData As String
      theData = aReader.ReadToEnd
      Return Analyze(theData)
    Catch E As Exception
      Console.WriteLine(E.StackTrace)
      Console.ReadLine()
    End Try
  End Function

  Private Function Analyze(ByVal theData As String) As Integer
    Dim Location As Integer
    Location = theData.IndexOf("<b>Amazon.com Sales Rank: </b>") _
    + "<b>Amazon.com Sales Rank: </b>".Length
    Dim temp As String
    Do Until theData.Substring(Location, 1) = "<"
      temp = temp & theData.Substring(Location, 1)
      Location += 1
    Loop
    Return CInt(temp)
  End Function
End Class
