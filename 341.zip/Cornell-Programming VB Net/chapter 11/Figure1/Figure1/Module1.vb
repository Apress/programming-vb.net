Option Strict On
Imports System.Data.OleDb
Module Module1
  Sub Main()
    Dim myAccessConn As OleDbConnection
    Dim dbReader As OleDbDataReader
    Dim dbCmd As OleDbCommand = New OleDbCommand( _
"SELECT Employees.FirstName, Employees.LastName FROM Employees")
    Try
      'open the connection
      myAccessConn = New OleDbConnection( _
"Provider=Microsoft.Jet.OLEDB.4.0;" & _
"Data Source=C:\Program Files\Microsoft Office\Office\Samples\Northwind.mdb")
      myAccessConn.Open()
      dbCmd.Connection = myAccessConn
      dbReader = dbCmd.ExecuteReader(CommandBehavior.SingleResult)
      Do While dbReader.Read()
        Console.WriteLine(dbReader.GetString(0) & " " & dbReader.GetString(1))
      Loop
      Console.ReadLine()
    Catch e As Exception
      MsgBox(e.Message)
    End Try
  End Sub
End Module
