'frmMain.vb
Imports System.Data.SqlClient
Public Class frmMain
  Inherits System.Windows.Forms.Form
#Region " Windows Form Designer generated code "
  Public Sub New()
    MyBase.New()
    'This call is required by the Windows Form Designer.
    InitializeComponent()
    'Add any initialization after the InitializeComponent() call
  End Sub
  'Form overrides dispose to clean up the component list.
  Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
    If Disposing Then
      If Not (components Is Nothing) Then
        components.Dispose()
      End If
    End If
    MyBase.Dispose(Disposing)
  End Sub
  Private WithEvents Label1 As System.Windows.Forms.Label
  Private WithEvents Label2 As System.Windows.Forms.Label
  Private WithEvents Label3 As System.Windows.Forms.Label
  Private WithEvents Label4 As System.Windows.Forms.Label
  Private WithEvents btnConnect As System.Windows.Forms.Button
  Private WithEvents txtUID As System.Windows.Forms.TextBox
  Private WithEvents txtPassword As System.Windows.Forms.TextBox
  Private WithEvents txtDatabase As System.Windows.Forms.TextBox
  Private WithEvents txtServer As System.Windows.Forms.TextBox
  'Required by the Windows Form Designer
  Private components As System.ComponentModel.Container
  'NOTE: The following procedure is required by the Windows Form Designer
  'It can be modified using the Windows Form Designer.  
  'Do not modify it using the code editor.
  <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
    Me.Label4 = New System.Windows.Forms.Label()
    Me.txtPassword = New System.Windows.Forms.TextBox()
    Me.Label1 = New System.Windows.Forms.Label()
    Me.txtServer = New System.Windows.Forms.TextBox()
    Me.Label2 = New System.Windows.Forms.Label()
    Me.Label3 = New System.Windows.Forms.Label()
    Me.txtUID = New System.Windows.Forms.TextBox()
    Me.txtDatabase = New System.Windows.Forms.TextBox()
    Me.btnConnect = New System.Windows.Forms.Button()
    Me.SuspendLayout()
    '
    'Label4
    '
    Me.Label4.Location = New System.Drawing.Point(24, 176)
    Me.Label4.Name = "Label4"
    Me.Label4.Size = New System.Drawing.Size(82, 19)
    Me.Label4.TabIndex = 0
    Me.Label4.Text = "Password:"
    Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight
    '
    'txtPassword
    '
    Me.txtPassword.Location = New System.Drawing.Point(168, 168)
    Me.txtPassword.Name = "txtPassword"
    Me.txtPassword.PasswordChar = ChrW(42)
    Me.txtPassword.Size = New System.Drawing.Size(205, 22)
    Me.txtPassword.TabIndex = 3
    Me.txtPassword.Text = ""
    '
    'Label1
    '
    Me.Label1.Location = New System.Drawing.Point(24, 32)
    Me.Label1.Name = "Label1"
    Me.Label1.Size = New System.Drawing.Size(82, 20)
    Me.Label1.TabIndex = 0
    Me.Label1.Text = "Server:"
    Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
    '
    'txtServer
    '
    Me.txtServer.Location = New System.Drawing.Point(168, 24)
    Me.txtServer.Name = "txtServer"
    Me.txtServer.Size = New System.Drawing.Size(205, 22)
    Me.txtServer.TabIndex = 0
    Me.txtServer.Text = ""
    '
    'Label2
    '
    Me.Label2.Location = New System.Drawing.Point(24, 80)
    Me.Label2.Name = "Label2"
    Me.Label2.Size = New System.Drawing.Size(82, 20)
    Me.Label2.TabIndex = 0
    Me.Label2.Text = "Database:"
    Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
    '
    'Label3
    '
    Me.Label3.Anchor = System.Windows.Forms.AnchorStyles.None
    Me.Label3.Location = New System.Drawing.Point(24, 128)
    Me.Label3.Name = "Label3"
    Me.Label3.Size = New System.Drawing.Size(82, 20)
    Me.Label3.TabIndex = 0
    Me.Label3.Text = "User ID:"
    Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight
    '
    'txtUID
    '
    Me.txtUID.Location = New System.Drawing.Point(168, 120)
    Me.txtUID.Name = "txtUID"
    Me.txtUID.Size = New System.Drawing.Size(205, 22)
    Me.txtUID.TabIndex = 2
    Me.txtUID.Text = ""
    '
    'txtDatabase
    '
    Me.txtDatabase.Location = New System.Drawing.Point(168, 72)
    Me.txtDatabase.Name = "txtDatabase"
    Me.txtDatabase.Size = New System.Drawing.Size(205, 22)
    Me.txtDatabase.TabIndex = 1
    Me.txtDatabase.Text = ""
    '
    'btnConnect
    '
    Me.btnConnect.Location = New System.Drawing.Point(160, 232)
    Me.btnConnect.Name = "btnConnect"
    Me.btnConnect.Size = New System.Drawing.Size(92, 30)
    Me.btnConnect.TabIndex = 4
    Me.btnConnect.Text = "&Connect"
    '
    'frmMain
    '
    Me.AutoScaleBaseSize = New System.Drawing.Size(6, 15)
    Me.ClientSize = New System.Drawing.Size(408, 280)
    Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnConnect, Me.txtPassword, Me.txtUID, Me.txtDatabase, Me.txtServer, Me.Label4, Me.Label3, Me.Label2, Me.Label1})
    Me.Name = "frmMain"
    Me.Text = "DB Connector"
    Me.ResumeLayout(False)

  End Sub
#End Region
  Private Sub btnConnect_Click(ByVal sender As System.Object, _
ByVal e As System.EventArgs) Handles btnConnect.Click
    Try
      mySQLConn = New SqlConnection("user id=" & txtUID.Text & _
                                    ";password=" & txtPassword.Text & _
                                    ";database=" & txtDatabase.Text & _
                                    ";server=" & txtServer.Text)
      mySQLConn.Open()
      dbCmd.Connection = mySQLConn
      Dim frmChild As New frmResults()
      frmChild.Show()
    Catch except As Exception
      MsgBox( _
"Failed to connect for the following reason: <" & _
except.Message & ">")
    End Try
  End Sub

End Class