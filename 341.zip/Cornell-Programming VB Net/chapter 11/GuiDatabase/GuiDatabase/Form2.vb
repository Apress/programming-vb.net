'frmResults.vb
Imports System.Data.SqlClient
Public Class frmResults
  Inherits System.Windows.Forms.Form
#Region " Windows Form Designer generated code "
  Public Sub New()
    MyBase.New()
    'This call is required by the Windows Form Designer.
    InitializeComponent()
    'Add any initialization after the InitializeComponent() call
  End Sub
  'Form overrides dispose to clean up the component list.
  Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
    If Disposing Then
      If Not (components Is Nothing) Then
        components.Dispose()
      End If
    End If
    MyBase.Dispose(Disposing)
  End Sub
  Private WithEvents txtQuery As System.Windows.Forms.TextBox
  Private WithEvents btnQuery As System.Windows.Forms.Button
  Private WithEvents lstData As System.Windows.Forms.ListBox
  'Required by the Windows Form Designer
  Private components As System.ComponentModel.Container
  'NOTE: The following procedure is required by the Windows Form Designer
  'It can be modified using the Windows Form Designer.  
  'Do not modify it using the code editor.
  <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
    Me.txtQuery = New System.Windows.Forms.TextBox()
    Me.btnQuery = New System.Windows.Forms.Button()
    Me.lstData = New System.Windows.Forms.ListBox()
    Me.SuspendLayout()
    '
    'txtQuery
    '
    Me.txtQuery.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txtQuery.Location = New System.Drawing.Point(10, 16)
    Me.txtQuery.Name = "txtQuery"
    Me.txtQuery.Size = New System.Drawing.Size(553, 24)
    Me.txtQuery.TabIndex = 1
    Me.txtQuery.Text = "Place SQL query here"
    '
    'btnQuery
    '
    Me.btnQuery.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.btnQuery.Location = New System.Drawing.Point(563, 16)
    Me.btnQuery.Name = "btnQuery"
    Me.btnQuery.Size = New System.Drawing.Size(72, 30)
    Me.btnQuery.TabIndex = 2
    Me.btnQuery.Text = "&Execute"
    '
    'lstData
    '
    Me.lstData.ColumnWidth = 120
    Me.lstData.ItemHeight = 16
    Me.lstData.Location = New System.Drawing.Point(10, 56)
    Me.lstData.MultiColumn = True
    Me.lstData.Name = "lstData"
    Me.lstData.Size = New System.Drawing.Size(625, 420)
    Me.lstData.TabIndex = 3
    '
    'frmResults
    '
    Me.AutoScaleBaseSize = New System.Drawing.Size(6, 15)
    Me.ClientSize = New System.Drawing.Size(645, 489)
    Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.lstData, Me.btnQuery, Me.txtQuery})
    Me.Name = "frmResults"
    Me.Text = "Query Window"
    Me.ResumeLayout(False)

  End Sub
#End Region
  Private Sub btnQuery_Click(ByVal sender As System.Object, _
ByVal e As System.EventArgs) Handles btnQuery.Click
    Try
      dbCmd.CommandText = txtQuery.Text
      dbReader = dbCmd.ExecuteReader(CommandBehavior.SingleResult)
      'get the schema of the table
      Dim dtblInfo As DataTable = dbReader.GetSchemaTable()
      'place holder variable while iterating rows
      Dim rwRow As DataRow
      Dim strHeaders As System.Text.StringBuilder = _
    New System.Text.StringBuilder()
      Dim strData As System.Text.StringBuilder = New System.Text.StringBuilder()
      Dim typTypes(dtblInfo.Columns.Count) As Type
      Dim intCounter As Integer = 0
      'loop through each row in the metadata
      For Each rwRow In dtblInfo.Rows
        'get the type of the value in the row
        typTypes(intCounter) = rwRow("DataType")
        intCounter += 1
        'add the column heading to the string
        strHeaders.Append("<" & rwRow(0) & ">" & vbTab)
      Next
      'write the header to the listbox
      lstData.Items.Add(strHeaders.ToString())
      'loop through the rows of data that we really care about
      Do While dbReader.Read()
        'read once for each column
        For intCounter = 0 To (dbReader.FieldCount - 1)
          'add the column data to the output string
          strData.Append(GetProperType(dbReader, intCounter, _
 typTypes(intCounter)) & vbTab)
        Next
        'write the data to the listbox
        lstData.Items.Add(strData.ToString())
        'clear the string builder
        strData = New System.Text.StringBuilder()
      Loop
    Catch except As Exception
      MsgBox("Error: " & except.Message)
    End Try
  End Sub
  'this function gets the value of a specific column
  Private Function GetProperType(ByVal dr As SqlDataReader, _
                         ByVal intPos As Integer, _
                         ByVal typType As Type) As Object
    'get the type of the field - then get the value
    Select Case typType.Name
      Case "String"
        'cast and return 
        Return CType(dr.GetString(intPos), String)
      Case "Int32"
        'cast and return
        Return CType(dr.GetInt32(intPos), Int32)
        'here is where you could check for all other 
        'types and return them as necessary. I just go the easy 
        'route and check for the most common 2
      Case Else
        Return "<Unsupported Type>"
    End Select
  End Function
End Class
