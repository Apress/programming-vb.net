Imports System.Data.SqlClient
Module main
  'Global definitions
  Public mySQLConn As SqlConnection
  Public dbReader As SqlDataReader
  Public dbCmd As SqlCommand = New SqlCommand()
End Module
