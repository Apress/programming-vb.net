Imports System.Data.SqlClient
Module Module1
  Sub Main()
    Dim mySQLConnString As String
    Dim mySQLConn As SqlConnection
    Dim dbReader As SqlDataReader
    Dim dbCmd As SqlCommand = New SqlCommand( _
  "SELECT Employees.FirstName, Employees.LastName FROM Employees")
    Try
      mySQLConnString = "uid=test;password=apress;database=northwind;server=COMPAQ"
      mySQLConn = New SqlConnection(mySQLConnString)
      mySQLConn.Open()
      dbCmd.Connection = mySQLConn
      dbReader = dbCmd.ExecuteReader(CommandBehavior.SingleResult)
      Do While dbReader.Read()
        'write the data to the screen
        Console.WriteLine(dbReader.GetString(0) & "," & _
                          dbReader.GetString(1))
      Loop
    Catch e As Exception
      MsgBox(e.Message)
    End Try
    Console.ReadLine()
  End Sub
End Module
