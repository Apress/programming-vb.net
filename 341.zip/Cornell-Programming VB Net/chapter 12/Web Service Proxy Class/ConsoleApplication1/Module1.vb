Module Module1
    
  Sub Main()
    Dim testClass As New ConsoleApplication1.localhost.Service1()
    MsgBox(testClass.GetWeather("Seattle"))
  End Sub
End Module
