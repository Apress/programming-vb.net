Option Strict On
Module Module1
    Sub Main()
        Dim river As String = " Mississippi Missippi" 'one space on left
        Console.WriteLine(river.ToUpper())
        Console.WriteLine(river.ToLower())
        Console.WriteLine(river.Trim())
        Console.WriteLine(river.EndsWith("I"))
        Console.WriteLine(river.EndsWith("i"))
        Console.WriteLine(river.IndexOf("s")) 'REMEMBER 0 based!
        Console.WriteLine(river.Insert(9, " river")) 'REMEMBER 0 based! 
        Console.ReadLine()
    End Sub
End Module
