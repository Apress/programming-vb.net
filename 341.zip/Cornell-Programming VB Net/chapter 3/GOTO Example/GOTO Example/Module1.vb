Option Strict On
Module Module1
    Sub Main()
        Dim getData As String
        Dim i, j As Integer
        For i = 1 To 10
            For j = 1 To 100
                Console.Write("Type the data, hit the Enter key between " & _
                    "ZZZ to end:  ")
                getData = Console.ReadLine()
                If getData = "ZZZ" Then
                    GoTo BadInput
                Else
                    'Process data
                End If
            Next j
        Next i
        Exit Sub
BadInput:
        Console.WriteLine("Data entry ended at user request")
        Console.ReadLine()
    End Sub
End Module
