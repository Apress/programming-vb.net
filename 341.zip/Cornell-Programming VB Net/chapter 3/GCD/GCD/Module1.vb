Option Strict On
Module Module1
  Function GCD(ByVal p As Long, ByVal q As Long) As Long
    If Q Mod P = 0 Then
      Return P
    Else
      Return GCD(Q, P Mod Q)
    End If
  End Function
  Public Sub Main()
    Console.WriteLine("The GCD of 36 and 99 is " & GCD(36, 99))
    Console.ReadLine()
  End Sub
End Module
