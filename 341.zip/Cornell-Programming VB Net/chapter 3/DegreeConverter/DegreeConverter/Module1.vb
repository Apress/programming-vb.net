'Degree converter
Option Strict On
Module Module1
    Sub Main()
        Dim cdeg As Decimal
        Console.Write("Enter the degrees in centigrade...")
        cdeg = CDec(Console.ReadLine())
        Dim fdeg As Decimal
        fdeg = (((9@ / 5) * cdeg) + 32)
        Console.WriteLine(cdeg & " is " & fdeg & " degrees Fahrenheit.")
        Console.ReadLine()
    End Sub
End Module