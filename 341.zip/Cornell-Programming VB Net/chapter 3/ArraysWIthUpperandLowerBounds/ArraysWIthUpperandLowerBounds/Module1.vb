Option Strict On
Module Module1
    Sub Main()
        Dim anArray As Array
        Dim i As Integer
        Dim l(0) As Integer
        Dim lowerBounds(0) As Integer
        l(0) = 7
        lowerBounds(0) = 1995
        'creates an array of objects numbered 1995 - 2002
        anArray = Array.CreateInstance(GetType(System.Int32), l, lowerBounds)
        anArray.SetValue(200000, 1995)
        anArray.SetValue(1000000, 2001)
        Console.WriteLine("The entry in position 1995 is " & _
        (anArray.GetValue(1995).ToString))
        Console.WriteLine("The entry in position 2002 is " & _
        (anArray.GetValue(2001).ToString))
        Console.ReadLine()
    End Sub
End Module
