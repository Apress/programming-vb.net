Option Strict On
Module Module1
  Sub Main()
    console.WriteLine((4 / 2).GetType())
    Console.ReadLine()
  End Sub
End Module
