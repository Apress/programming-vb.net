Module Module1
    Public Sub Main()
        Dim tom As New Employee("Tom", 50000)
        Dim sally As New Employee("Sally", 150000)
        Dim temp() As Employee = {tom, sally}
        Dim ourEmployees As New Employees(temp)
        Dim anEmployee As Employee
        For Each anEmployee In ourEmployees
            anEmployee.RaiseSalary(0.1D)
            Console.WriteLine(anEmployee.TheName & " salary now is " & _
              anEmployee.Salary())
        Next
        ourEmployees.Reset()
        For Each anEmployee In ourEmployees
            anEmployee.RaiseSalary(0.1D)
            Console.WriteLine(anEmployee.TheName & " salary now is " & _
              anEmployee.Salary())
        Next
        Console.ReadLine()
    End Sub
End Module
Public Class Employees
    Implements IEnumerable, IEnumerator
    Private m_Employees() As Employee
    Private m_Index As Integer = -1
    Private m_Count As Integer = 0
    Public Function GetEnumerator() As IEnumerator _
    Implements IEnumerable.GetEnumerator
        Return Me
    End Function
    Public ReadOnly Property Current() As Object _
  Implements IEnumerator.Current
        Get
            Return m_Employees(m_Index)
        End Get
    End Property
    Public Function MoveNext() As Boolean _
    Implements IEnumerator.MoveNext
        If m_Index < m_Count Then
            m_Index += 1
            Return True
        Else
            Return False
        End If
    End Function
    Public Sub Reset() Implements IEnumerator.Reset
        m_Index = -1
    End Sub
    Public Sub New(ByVal theEmployees() As Employee)
        If theEmployees Is Nothing Then
            MsgBox("No items in the collection")
            'should throw an exception see Chapter 7
            'Throw New ApplicationException()
        Else
            m_Count = theEmployees.Length - 1
            m_Employees = theEmployees
        End If
    End Sub
End Class
Public Class Employee
    Private m_Name As String
    Private m_Salary As Decimal
    Private Const LIMIT As Decimal = 0.1D

    Public Sub New(ByVal theName As String, ByVal curSalary As Decimal)
        m_Name = theName
        m_Salary = curSalary
    End Sub

    Public ReadOnly Property TheName() As String
        Get
            Return m_Name
        End Get
    End Property

    Public ReadOnly Property Salary() As Decimal
        Get
            Return MyClass.m_Salary
        End Get
    End Property

    Public Overridable Overloads Sub RaiseSalary(ByVal Percent As Decimal)
        If Percent > LIMIT Then
            'not allowed
            Console.WriteLine("NEED PASSWORD TO RAISE SALARY MORE " & _
        "THAN LIMIT!!!!")
        Else
            m_Salary = (1 + Percent) * m_Salary
        End If
    End Sub

    Public Overridable Overloads Sub RaiseSalary(ByVal Percent As _
    Decimal, ByVal Password As String)
        If Password = "special" Then
            m_Salary = (1 + Percent) * m_Salary
        End If
    End Sub
End Class

